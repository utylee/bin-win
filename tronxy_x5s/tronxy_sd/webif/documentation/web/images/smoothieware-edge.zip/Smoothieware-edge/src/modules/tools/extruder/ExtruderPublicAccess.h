#pragma once

#define extruder_checksum                    CHECKSUM("extruder")
#define save_state_checksum                  CHECKSUM("save_state")
#define restore_state_checksum               CHECKSUM("restore_state")
#define target_checksum                      CHECKSUM("target")
