**NOTE**

Make sure you download the binary file and not the HTML page. 

Click the file you want, then click the View Raw button to get the raw binary file.

Flashing the HTML will mean the leds will not flash :)
