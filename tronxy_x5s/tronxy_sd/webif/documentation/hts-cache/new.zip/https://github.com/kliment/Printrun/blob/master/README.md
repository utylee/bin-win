



<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/frameworks-3c1694fab1568340f2e75b26efa1f55d97c5153364a7357e9e1104c718ff1a2f.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github-3e95d73eb454e0099947df00d91ab0dbfc6b10be69dd5daf5de7aeb676580d20.css" media="all" rel="stylesheet" />
    
    
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/site-c4b4365da282e51c06e107368db8502a2ecf82e64094d29d791b797372212de2.css" media="all" rel="stylesheet" />
    

    <link as="script" href="https://assets-cdn.github.com/assets/frameworks-f8175c23360b42a4eb18b2319fefeae252cfeea482fb804356f4136a52bfddb3.js" rel="preload" />
    
    <link as="script" href="https://assets-cdn.github.com/assets/github-1502104f450cb05859f99b57e29782e071e3fb240e237adb8cbf17ebbdb271c7.js" rel="preload" />

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta name="viewport" content="width=1020">
    
    
    <title>Printrun/README.md at master · kliment/Printrun · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="https://avatars2.githubusercontent.com/u/228211?v=3&amp;s=400" name="twitter:image:src" /><meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="kliment/Printrun" name="twitter:title" /><meta content="Printrun - Pronterface, Pronsole, and Printcore - Pure Python 3d printing host software" name="twitter:description" />
      <meta content="https://avatars2.githubusercontent.com/u/228211?v=3&amp;s=400" property="og:image" /><meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="kliment/Printrun" property="og:title" /><meta content="https://github.com/kliment/Printrun" property="og:url" /><meta content="Printrun - Pronterface, Pronsole, and Printcore - Pure Python 3d printing host software" property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>

    <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
<meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-analytics" content="UA-3769691-2">

<meta content="collector.githubapp.com" name="octolytics-host" /><meta content="github" name="octolytics-app-id" /><meta content="55A92EEF:7A03:1A8D5ED:5735BE9F" name="octolytics-dimension-request_id" />
<meta content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/show" data-pjax-transient="true" name="analytics-location" />



  <meta class="js-ga-set" name="dimension1" content="Logged Out">



        <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

        <meta name="expected-hostname" content="github.com">
      <meta name="js-proxy-site-detection-payload" content="ZDI3YmY5ZDM3ZmJhZjhjNDAzMGZmODIyZmFjMDgzM2VkYWJmNmFkZDFjZWFiN2ZlZDI0ODFjMTMyMGIxMTAxOXx7InJlbW90ZV9hZGRyZXNzIjoiODUuMTY5LjQ2LjIzOSIsInJlcXVlc3RfaWQiOiI1NUE5MkVFRjo3QTAzOjFBOEQ1RUQ6NTczNUJFOUYiLCJ0aW1lc3RhbXAiOjE0NjMxMzk5OTl9">


      <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#4078c0">
      <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">

    <meta content="d6013ef313dc33a770980c6e66b5cb1d7130dd9d" name="form-nonce" />

    <meta http-equiv="x-pjax-version" content="22dd3b7ce1aea89995da9e98ee8a9677">
    

      
  <meta name="description" content="Printrun - Pronterface, Pronsole, and Printcore - Pure Python 3d printing host software">
  <meta name="go-import" content="github.com/kliment/Printrun git https://github.com/kliment/Printrun.git">

  <meta content="228211" name="octolytics-dimension-user_id" /><meta content="kliment" name="octolytics-dimension-user_login" /><meta content="1726797" name="octolytics-dimension-repository_id" /><meta content="kliment/Printrun" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="1726797" name="octolytics-dimension-repository_network_root_id" /><meta content="kliment/Printrun" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/kliment/Printrun/commits/master.atom" rel="alternate" title="Recent Commits to Printrun:master" type="application/atom+xml">


      <link rel="canonical" href="https://github.com/kliment/Printrun/blob/master/README.md" data-pjax-transient>
  </head>


  <body class="logged-out   env-production  vis-public page-blob">
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"></div>
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>

    
    
    



          <header class="site-header js-details-container" role="banner">
  <div class="container-responsive">
    <a class="header-logo-invertocat" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <svg aria-hidden="true" class="octicon octicon-mark-github" height="32" version="1.1" viewBox="0 0 16 16" width="32"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59 0.4 0.07 0.55-0.17 0.55-0.38 0-0.19-0.01-0.82-0.01-1.49-2.01 0.37-2.53-0.49-2.69-0.94-0.09-0.23-0.48-0.94-0.82-1.13-0.28-0.15-0.68-0.52-0.01-0.53 0.63-0.01 1.08 0.58 1.23 0.82 0.72 1.21 1.87 0.87 2.33 0.66 0.07-0.52 0.28-0.87 0.51-1.07-1.78-0.2-3.64-0.89-3.64-3.95 0-0.87 0.31-1.59 0.82-2.15-0.08-0.2-0.36-1.02 0.08-2.12 0 0 0.67-0.21 2.2 0.82 0.64-0.18 1.32-0.27 2-0.27 0.68 0 1.36 0.09 2 0.27 1.53-1.04 2.2-0.82 2.2-0.82 0.44 1.1 0.16 1.92 0.08 2.12 0.51 0.56 0.82 1.27 0.82 2.15 0 3.07-1.87 3.75-3.65 3.95 0.29 0.25 0.54 0.73 0.54 1.48 0 1.07-0.01 1.93-0.01 2.2 0 0.21 0.15 0.46 0.55 0.38C13.71 14.53 16 11.53 16 8 16 3.58 12.42 0 8 0z"></path></svg>
    </a>

    <button class="btn-link right site-header-toggle js-details-target" type="button" aria-label="Toggle navigation">
      <svg aria-hidden="true" class="octicon octicon-three-bars" height="24" version="1.1" viewBox="0 0 12 16" width="18"><path d="M11.41 9H0.59c-0.59 0-0.59-0.41-0.59-1s0-1 0.59-1h10.81c0.59 0 0.59 0.41 0.59 1s0 1-0.59 1z m0-4H0.59c-0.59 0-0.59-0.41-0.59-1s0-1 0.59-1h10.81c0.59 0 0.59 0.41 0.59 1s0 1-0.59 1zM0.59 11h10.81c0.59 0 0.59 0.41 0.59 1s0 1-0.59 1H0.59c-0.59 0-0.59-0.41-0.59-1s0-1 0.59-1z"></path></svg>
    </button>

    <div class="site-header-menu">
      <nav class="site-header-nav site-header-nav-main">
        <a href="/personal" class="js-selected-navigation-item nav-item nav-item-personal" data-ga-click="Header, click, Nav menu - item:personal" data-selected-links="/personal /personal">
          Personal
</a>        <a href="/open-source" class="js-selected-navigation-item nav-item nav-item-opensource" data-ga-click="Header, click, Nav menu - item:opensource" data-selected-links="/open-source /open-source">
          Open source
</a>        <a href="/business" class="js-selected-navigation-item nav-item nav-item-business" data-ga-click="Header, click, Nav menu - item:business" data-selected-links="/business /business/features /business/customers /business">
          Business
</a>        <a href="/explore" class="js-selected-navigation-item nav-item nav-item-explore" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship /explore">
          Explore
</a>      </nav>

      <div class="site-header-actions">
            <a class="btn btn-primary site-header-actions-btn" href="/join?source=header-repo" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
          <a class="btn site-header-actions-btn mr-2" href="/login?return_to=%2Fkliment%2FPrintrun%2Fblob%2Fmaster%2FREADME.md" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
      </div>

        <nav class="site-header-nav site-header-nav-secondary">
          <a class="nav-item" href="/pricing">Pricing</a>
          <a class="nav-item" href="/blog">Blog</a>
          <a class="nav-item" href="https://help.github.com">Support</a>
          <a class="nav-item header-search-link" href="https://github.com/search">Search GitHub</a>
              <div class="header-search scoped-search site-scoped-search js-site-search" role="search">
  <!-- </textarea> --><!-- '"` --><form accept-charset="UTF-8" action="/kliment/Printrun/search" class="js-site-search-form" data-scoped-search-url="/kliment/Printrun/search" data-unscoped-search-url="/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
    <label class="form-control header-search-wrapper js-chromeless-input-container">
      <div class="header-search-scope">This repository</div>
      <input type="text"
        class="form-control header-search-input js-site-search-focus js-site-search-field is-clearable"
        data-hotkey="s"
        name="q"
        placeholder="Search"
        aria-label="Search this repository"
        data-unscoped-placeholder="Search GitHub"
        data-scoped-placeholder="Search"
        tabindex="1"
        autocapitalize="off">
    </label>
</form></div>

        </nav>
    </div>
  </div>
</header>



    <div id="start-of-content" class="accessibility-aid"></div>

      <div id="js-flash-container">
</div>


    <div role="main" class="main-content">
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode">
    <div id="js-repo-pjax-container" data-pjax-container>
      
<div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav">
  <div class="container repohead-details-container">

    

<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fkliment%2FPrintrun"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-eye" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6c4.94 0 7.94-6 7.94-6S13 2 8.06 2z m-0.06 10c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4z m2-4c0 1.11-0.89 2-2 2s-2-0.89-2-2 0.89-2 2-2 2 0.89 2 2z"></path></svg>
    Watch
  </a>
  <a class="social-count" href="/kliment/Printrun/watchers">
    148
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fkliment%2FPrintrun"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-star" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path d="M14 6l-4.9-0.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14l4.33-2.33 4.33 2.33L10.4 9.26 14 6z"></path></svg>
    Star
  </a>

    <a class="social-count js-social-count" href="/kliment/Printrun/stargazers">
      834
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fkliment%2FPrintrun"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg aria-hidden="true" class="octicon octicon-repo-forked" height="16" version="1.1" viewBox="0 0 10 16" width="10"><path d="M8 1c-1.11 0-2 0.89-2 2 0 0.73 0.41 1.38 1 1.72v1.28L5 8 3 6v-1.28c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2S0 1.89 0 3c0 0.73 0.41 1.38 1 1.72v1.78l3 3v1.78c-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72V9.5l3-3V4.72c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2zM2 4.2c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3 10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3-10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z"></path></svg>
        Fork
      </a>

    <a href="/kliment/Printrun/network" class="social-count">
      522
    </a>
  </li>
</ul>

    <h1 class="entry-title public ">
  <svg aria-hidden="true" class="octicon octicon-repo" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M4 9h-1v-1h1v1z m0-3h-1v1h1v-1z m0-2h-1v1h1v-1z m0-2h-1v1h1v-1z m8-1v12c0 0.55-0.45 1-1 1H6v2l-1.5-1.5-1.5 1.5V14H1c-0.55 0-1-0.45-1-1V1C0 0.45 0.45 0 1 0h10c0.55 0 1 0.45 1 1z m-1 10H1v2h2v-1h3v1h5V11z m0-10H2v9h9V1z"></path></svg>
  <span class="author" itemprop="author"><a href="/kliment" class="url fn" rel="author">kliment</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a href="/kliment/Printrun" data-pjax="#js-repo-pjax-container">Printrun</a></strong>

</h1>

  </div>
  <div class="container">
    
<nav class="reponav js-repo-nav js-sidenav-container-pjax"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
     role="navigation"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/kliment/Printrun" aria-selected="true" class="js-selected-navigation-item selected reponav-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /kliment/Printrun" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path d="M9.5 3l-1.5 1.5 3.5 3.5L8 11.5l1.5 1.5 4.5-5L9.5 3zM4.5 3L0 8l4.5 5 1.5-1.5L2.5 8l3.5-3.5L4.5 3z"></path></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a href="/kliment/Printrun/issues" class="js-selected-navigation-item reponav-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /kliment/Printrun/issues" itemprop="url">
        <svg aria-hidden="true" class="octicon octicon-issue-opened" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7S10.14 13.7 7 13.7 1.3 11.14 1.3 8s2.56-5.7 5.7-5.7m0-1.3C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7S10.86 1 7 1z m1 3H6v5h2V4z m0 6H6v2h2V10z"></path></svg>
        <span itemprop="name">Issues</span>
        <span class="counter">122</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/kliment/Printrun/pulls" class="js-selected-navigation-item reponav-item" data-hotkey="g p" data-selected-links="repo_pulls /kliment/Printrun/pulls" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-git-pull-request" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M11 11.28c0-1.73 0-6.28 0-6.28-0.03-0.78-0.34-1.47-0.94-2.06s-1.28-0.91-2.06-0.94c0 0-1.02 0-1 0V0L4 3l3 3V4h1c0.27 0.02 0.48 0.11 0.69 0.31s0.3 0.42 0.31 0.69v6.28c-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72z m-1 2.92c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2zM4 3c0-1.11-0.89-2-2-2S0 1.89 0 3c0 0.73 0.41 1.38 1 1.72 0 1.55 0 5.56 0 6.56-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72V4.72c0.59-0.34 1-0.98 1-1.72z m-0.8 10c0 0.66-0.55 1.2-1.2 1.2s-1.2-0.55-1.2-1.2 0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2z m-1.2-8.8c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z"></path></svg>
      <span itemprop="name">Pull requests</span>
      <span class="counter">4</span>
      <meta itemprop="position" content="3">
</a>  </span>



  <a href="/kliment/Printrun/pulse" class="js-selected-navigation-item reponav-item" data-selected-links="pulse /kliment/Printrun/pulse">
    <svg aria-hidden="true" class="octicon octicon-pulse" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path d="M11.5 8L8.8 5.4 6.6 8.5 5.5 1.6 2.38 8H0V10h3.6L4.5 8.2l0.9 5.4L9 8.5l1.6 1.5H14V8H11.5z"></path></svg>
    Pulse
</a>
  <a href="/kliment/Printrun/graphs" class="js-selected-navigation-item reponav-item" data-selected-links="repo_graphs repo_contributors /kliment/Printrun/graphs">
    <svg aria-hidden="true" class="octicon octicon-graph" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M16 14v1H0V0h1v14h15z m-11-1H3V8h2v5z m4 0H7V3h2v10z m4 0H11V6h2v7z"></path></svg>
    Graphs
</a>

</nav>

  </div>
</div>

<div class="container new-discussion-timeline experiment-repo-nav">
  <div class="repository-content">

    

<a href="/kliment/Printrun/blob/0657d73f82f02121772c0341fb5199381c7199d5/README.md" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<!-- blob contrib key: blob_contributors:v21:121a82df5ced3f3cc6189c2e82340948 -->

<div class="file-navigation js-zeroclipboard-container">
  
<div class="select-menu branch-select-menu js-menu-container js-select-menu left">
  <button class="btn btn-sm select-menu-button js-menu-target css-truncate" data-hotkey="w"
    title="master"
    type="button" aria-label="Switch branches or tags" tabindex="0" aria-haspopup="true">
    <i>Branch:</i>
    <span class="js-select-button css-truncate-target">master</span>
  </button>

  <div class="select-menu-modal-holder js-menu-content js-navigation-container" data-pjax aria-hidden="true">

    <div class="select-menu-modal">
      <div class="select-menu-header">
        <svg aria-label="Close" class="octicon octicon-x js-menu-close" height="16" role="img" version="1.1" viewBox="0 0 12 16" width="12"><path d="M7.48 8l3.75 3.75-1.48 1.48-3.75-3.75-3.75 3.75-1.48-1.48 3.75-3.75L0.77 4.25l1.48-1.48 3.75 3.75 3.75-3.75 1.48 1.48-3.75 3.75z"></path></svg>
        <span class="select-menu-title">Switch branches/tags</span>
      </div>

      <div class="select-menu-filters">
        <div class="select-menu-text-filter">
          <input type="text" aria-label="Filter branches/tags" id="context-commitish-filter-field" class="form-control js-filterable-field js-navigation-enable" placeholder="Filter branches/tags">
        </div>
        <div class="select-menu-tabs">
          <ul>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="branches" data-filter-placeholder="Filter branches/tags" class="js-select-menu-tab" role="tab">Branches</a>
            </li>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="tags" data-filter-placeholder="Find a tag…" class="js-select-menu-tab" role="tab">Tags</a>
            </li>
          </ul>
        </div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="branches" role="menu">

        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/kliment/Printrun/blob/gh-pages/README.md"
               data-name="gh-pages"
               data-skip-pjax="true"
               rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target js-select-menu-filter-text" title="gh-pages">
                gh-pages
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open selected"
               href="/kliment/Printrun/blob/master/README.md"
               data-name="master"
               data-skip-pjax="true"
               rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target js-select-menu-filter-text" title="master">
                master
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/kliment/Printrun/blob/py3/README.md"
               data-name="py3"
               data-skip-pjax="true"
               rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target js-select-menu-filter-text" title="py3">
                py3
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/kliment/Printrun/blob/stable/README.md"
               data-name="stable"
               data-skip-pjax="true"
               rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target js-select-menu-filter-text" title="stable">
                stable
              </span>
            </a>
        </div>

          <div class="select-menu-no-results">Nothing to show</div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="tags">
        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20150310/README.md"
              data-name="printrun-20150310"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20150310">
                printrun-20150310
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20140801/README.md"
              data-name="printrun-20140801"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20140801">
                printrun-20140801
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20140730/README.md"
              data-name="printrun-20140730"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20140730">
                printrun-20140730
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20140406/README.md"
              data-name="printrun-20140406"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20140406">
                printrun-20140406
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20140328/README.md"
              data-name="printrun-20140328"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20140328">
                printrun-20140328
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20140126/README.md"
              data-name="printrun-20140126"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20140126">
                printrun-20140126
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20131019/README.md"
              data-name="printrun-20131019"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20131019">
                printrun-20131019
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20130711/README.md"
              data-name="printrun-20130711"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20130711">
                printrun-20130711
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
              href="/kliment/Printrun/tree/printrun-20130604/README.md"
              data-name="printrun-20130604"
              data-skip-pjax="true"
              rel="nofollow">
              <svg aria-hidden="true" class="octicon octicon-check select-menu-item-icon" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M12 5L4 13 0 9l1.5-1.5 2.5 2.5 6.5-6.5 1.5 1.5z"></path></svg>
              <span class="select-menu-item-text css-truncate-target" title="printrun-20130604">
                printrun-20130604
              </span>
            </a>
        </div>

        <div class="select-menu-no-results">Nothing to show</div>
      </div>

    </div>
  </div>
</div>

  <div class="btn-group right">
    <a href="/kliment/Printrun/find/master"
          class="js-pjax-capture-input btn btn-sm"
          data-pjax
          data-hotkey="t">
      Find file
    </a>
    <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button">Copy path</button>
  </div>
  <div class="breadcrumb js-zeroclipboard-target">
    <span class="repo-root js-repo-root"><span class="js-path-segment"><a href="/kliment/Printrun"><span>Printrun</span></a></span></span><span class="separator">/</span><strong class="final-path">README.md</strong>
  </div>
</div>


  <div class="commit-tease">
      <span class="right">
        <a class="commit-tease-sha" href="/kliment/Printrun/commit/1a65c0dca0b413fb90696f7b27389da5f3f6fdb4" data-pjax>
          1a65c0d
        </a>
        <time datetime="2016-02-21T13:29:20Z" is="relative-time">Feb 21, 2016</time>
      </span>
      <div>
        <img alt="@smurfix" class="avatar" height="20" src="https://avatars2.githubusercontent.com/u/236571?v=3&amp;s=40" width="20" />
        <a href="/smurfix" class="user-mention" rel="contributor">smurfix</a>
          <a href="/kliment/Printrun/commit/1a65c0dca0b413fb90696f7b27389da5f3f6fdb4" class="message" data-pjax="true" title="README: yet another Python module">README: yet another Python module</a>
      </div>

    <div class="commit-tease-contributors">
      <button type="button" class="btn-link muted-link contributors-toggle" data-facebox="#blob_contributors_box">
        <strong>14</strong>
         contributors
      </button>
          <a class="avatar-link tooltipped tooltipped-s" aria-label="iXce" href="/kliment/Printrun/commits/master/README.md?author=iXce"><img alt="@iXce" class="avatar" height="20" src="https://avatars0.githubusercontent.com/u/1085885?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="D1plo1d" href="/kliment/Printrun/commits/master/README.md?author=D1plo1d"><img alt="@D1plo1d" class="avatar" height="20" src="https://avatars0.githubusercontent.com/u/145184?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="kliment" href="/kliment/Printrun/commits/master/README.md?author=kliment"><img alt="@kliment" class="avatar" height="20" src="https://avatars0.githubusercontent.com/u/228211?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="brendanjerwin" href="/kliment/Printrun/commits/master/README.md?author=brendanjerwin"><img alt="@brendanjerwin" class="avatar" height="20" src="https://avatars2.githubusercontent.com/u/3039?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="bmcage" href="/kliment/Printrun/commits/master/README.md?author=bmcage"><img alt="@bmcage" class="avatar" height="20" src="https://avatars0.githubusercontent.com/u/1011414?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="hroncok" href="/kliment/Printrun/commits/master/README.md?author=hroncok"><img alt="@hroncok" class="avatar" height="20" src="https://avatars1.githubusercontent.com/u/2401856?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="alexrj" href="/kliment/Printrun/commits/master/README.md?author=alexrj"><img alt="@alexrj" class="avatar" height="20" src="https://avatars3.githubusercontent.com/u/594957?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="felipesanches" href="/kliment/Printrun/commits/master/README.md?author=felipesanches"><img alt="@felipesanches" class="avatar" height="20" src="https://avatars1.githubusercontent.com/u/213676?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="evilB" href="/kliment/Printrun/commits/master/README.md?author=evilB"><img alt="@evilB" class="avatar" height="20" src="https://avatars2.githubusercontent.com/u/1163676?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="skade" href="/kliment/Printrun/commits/master/README.md?author=skade"><img alt="@skade" class="avatar" height="20" src="https://avatars2.githubusercontent.com/u/47542?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="bronzehedwick" href="/kliment/Printrun/commits/master/README.md?author=bronzehedwick"><img alt="@bronzehedwick" class="avatar" height="20" src="https://avatars3.githubusercontent.com/u/637174?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="k-eex" href="/kliment/Printrun/commits/master/README.md?author=k-eex"><img alt="@k-eex" class="avatar" height="20" src="https://avatars3.githubusercontent.com/u/774880?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="smurfix" href="/kliment/Printrun/commits/master/README.md?author=smurfix"><img alt="@smurfix" class="avatar" height="20" src="https://avatars2.githubusercontent.com/u/236571?v=3&amp;s=40" width="20" /> </a>
    <a class="avatar-link tooltipped tooltipped-s" aria-label="olasd" href="/kliment/Printrun/commits/master/README.md?author=olasd"><img alt="@olasd" class="avatar" height="20" src="https://avatars3.githubusercontent.com/u/12877?v=3&amp;s=40" width="20" /> </a>


    </div>

    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header" data-facebox-id="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list" data-facebox-id="facebox-description">
          <li class="facebox-user-list-item">
            <img alt="@iXce" height="24" src="https://avatars2.githubusercontent.com/u/1085885?v=3&amp;s=48" width="24" />
            <a href="/iXce">iXce</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@D1plo1d" height="24" src="https://avatars2.githubusercontent.com/u/145184?v=3&amp;s=48" width="24" />
            <a href="/D1plo1d">D1plo1d</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@kliment" height="24" src="https://avatars2.githubusercontent.com/u/228211?v=3&amp;s=48" width="24" />
            <a href="/kliment">kliment</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@brendanjerwin" height="24" src="https://avatars0.githubusercontent.com/u/3039?v=3&amp;s=48" width="24" />
            <a href="/brendanjerwin">brendanjerwin</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@bmcage" height="24" src="https://avatars2.githubusercontent.com/u/1011414?v=3&amp;s=48" width="24" />
            <a href="/bmcage">bmcage</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@hroncok" height="24" src="https://avatars3.githubusercontent.com/u/2401856?v=3&amp;s=48" width="24" />
            <a href="/hroncok">hroncok</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@alexrj" height="24" src="https://avatars1.githubusercontent.com/u/594957?v=3&amp;s=48" width="24" />
            <a href="/alexrj">alexrj</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@felipesanches" height="24" src="https://avatars3.githubusercontent.com/u/213676?v=3&amp;s=48" width="24" />
            <a href="/felipesanches">felipesanches</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@evilB" height="24" src="https://avatars0.githubusercontent.com/u/1163676?v=3&amp;s=48" width="24" />
            <a href="/evilB">evilB</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@skade" height="24" src="https://avatars0.githubusercontent.com/u/47542?v=3&amp;s=48" width="24" />
            <a href="/skade">skade</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@bronzehedwick" height="24" src="https://avatars1.githubusercontent.com/u/637174?v=3&amp;s=48" width="24" />
            <a href="/bronzehedwick">bronzehedwick</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@k-eex" height="24" src="https://avatars1.githubusercontent.com/u/774880?v=3&amp;s=48" width="24" />
            <a href="/k-eex">k-eex</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@smurfix" height="24" src="https://avatars0.githubusercontent.com/u/236571?v=3&amp;s=48" width="24" />
            <a href="/smurfix">smurfix</a>
          </li>
          <li class="facebox-user-list-item">
            <img alt="@olasd" height="24" src="https://avatars1.githubusercontent.com/u/12877?v=3&amp;s=48" width="24" />
            <a href="/olasd">olasd</a>
          </li>
      </ul>
    </div>
  </div>

<div class="file">
  <div class="file-header">
  <div class="file-actions">

    <div class="btn-group">
      <a href="/kliment/Printrun/raw/master/README.md" class="btn btn-sm " id="raw-url">Raw</a>
        <a href="/kliment/Printrun/blame/master/README.md" class="btn btn-sm js-update-url-with-hash">Blame</a>
      <a href="/kliment/Printrun/commits/master/README.md" class="btn btn-sm " rel="nofollow">History</a>
    </div>


        <button type="button" class="btn-octicon disabled tooltipped tooltipped-nw"
          aria-label="You must be signed in to make or propose changes">
          <svg aria-hidden="true" class="octicon octicon-pencil" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path d="M0 12v3h3l8-8-3-3L0 12z m3 2H1V12h1v1h1v1z m10.3-9.3l-1.3 1.3-3-3 1.3-1.3c0.39-0.39 1.02-0.39 1.41 0l1.59 1.59c0.39 0.39 0.39 1.02 0 1.41z"></path></svg>
        </button>
        <button type="button" class="btn-octicon btn-octicon-danger disabled tooltipped tooltipped-nw"
          aria-label="You must be signed in to make or propose changes">
          <svg aria-hidden="true" class="octicon octicon-trashcan" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M10 2H8c0-0.55-0.45-1-1-1H4c-0.55 0-1 0.45-1 1H1c-0.55 0-1 0.45-1 1v1c0 0.55 0.45 1 1 1v9c0 0.55 0.45 1 1 1h7c0.55 0 1-0.45 1-1V5c0.55 0 1-0.45 1-1v-1c0-0.55-0.45-1-1-1z m-1 12H2V5h1v8h1V5h1v8h1V5h1v8h1V5h1v9z m1-10H1v-1h9v1z"></path></svg>
        </button>
  </div>

  <div class="file-info">
      474 lines (343 sloc)
      <span class="file-info-divider"></span>
    18.6 KB
  </div>
</div>

  
  <div id="readme" class="readme blob instapaper_body">
    <article class="markdown-body entry-content" itemprop="text"><p>Printrun consists of printcore, pronsole and pronterface, and a small collection of helpful scripts.</p>

<ul>
<li>printcore.py is a library that makes writing reprap hosts easy</li>
<li>pronsole.py is an interactive command-line host software with tabcompletion goodness</li>
<li>pronterface.py is a graphical host software with the same functionality as pronsole</li>
</ul>

<h1><a id="user-content-getting-printrun" class="anchor" href="#getting-printrun" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>GETTING PRINTRUN</h1>

<p>This section suggests using precompiled binaries, this way you get everything bundled into one single package for an easy installation.</p>

<p>If you want the newest, shiniest features, you can run Printrun from source using the instructions further down this README.</p>

<h2><a id="user-content-windows" class="anchor" href="#windows" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Windows</h2>

<p>A precompiled version is available at <a href="http://koti.kapsi.fi/%7Ekliment/printrun/">http://koti.kapsi.fi/~kliment/printrun/</a></p>

<h2><a id="user-content-mac-os-x" class="anchor" href="#mac-os-x" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Mac OS X</h2>

<p>A precompiled version is available at <a href="http://koti.kapsi.fi/%7Ekliment/printrun/">http://koti.kapsi.fi/~kliment/printrun/</a></p>

<h2><a id="user-content-linux" class="anchor" href="#linux" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Linux</h2>

<h3><a id="user-content-ubuntudebian" class="anchor" href="#ubuntudebian" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Ubuntu/Debian</h3>

<p>You can run Printrun directly from source, as there are no packages available yet. Fetch and install the dependencies using</p>

<ol>
<li><code>sudo apt-get install python-serial python-wxgtk2.8 python-pyglet python-numpy cython python-libxml2 python-gobject python-dbus python-psutil python-cairosvg git</code></li>
</ol>

<p>Clone the repository</p>

<p><code>git clone https://github.com/kliment/Printrun.git</code></p>

<p>and you can start using Printrun from the Printrun directory created by the git clone command.</p>

<h3><a id="user-content-chrome-os" class="anchor" href="#chrome-os" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Chrome OS</h3>

<p>You can use Printrun via crouton ( <a href="https://github.com/dnschneid/crouton">https://github.com/dnschneid/crouton</a> ). Assuming you want Ubuntu Trusty, you used probably <code>sudo sh -e ~/Downloads/crouton -r trusty -t xfce</code> to install Ubuntu. Fetch and install dependencies with the line given above for Ubuntu/Debian, and obtain the source via git clone.</p>

<p>By default you have no access to the serial port under Chrome OS crouton, so you cannot connect to your 3D printer. Add yourself to the serial group within the linux environment to fix this</p>

<p><code>sudo usermod -G serial -a &lt;username&gt;</code> </p>

<p>where <code>&lt;username&gt;</code> should be your username. Log out and in to make this group change active and allow communication with your printer. </p>

<h3><a id="user-content-fedora" class="anchor" href="#fedora" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Fedora</h3>

<p>You can install Printrun from official packages. Install the whole package using</p>

<p><code>sudo yum install printrun</code></p>

<p>Or get only apps you need by</p>

<p><code>sudo yum install pronsole</code> or <code>pronterface</code> or <code>plater</code></p>

<p>Adding <code>--enablerepo updates-testing</code> option to <code>yum</code> might give you newer packages (but also not very tested).</p>

<p>You can also run Printrun directly from source, if the packages are too old for you. Fetch and install the dependencies using</p>

<ol>
<li><code>sudo yum install pyserial wxPython python-pyglet python-cairosvg</code></li>
</ol>

<p>Optional: <code>sudo yum install skeinforge simarrange</code></p>

<h3><a id="user-content-archlinux" class="anchor" href="#archlinux" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Archlinux</h3>

<p>Packages are available in AUR. Just run</p>

<p><code>yaourt printrun</code></p>

<p>and enjoy the <code>pronterface</code>, <code>pronsole</code>, ... commands directly.</p>

<h2><a id="user-content-running-from-source" class="anchor" href="#running-from-source" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>RUNNING FROM SOURCE</h2>

<p>Run Printrun for source if you want to test out the latest features.</p>

<h3><a id="user-content-dependencies" class="anchor" href="#dependencies" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Dependencies</h3>

<p>To use pronterface, you need:</p>

<ul>
<li>python (ideally 2.6.x or 2.7.x),</li>
<li>pyserial (or python-serial on ubuntu/debian)</li>
<li>pyreadline (not needed on Linux) and</li>
<li>argparse (installed by default with python &gt;= 2.7)</li>
<li>wxPython (some features such as Tabbed mode work better with wx 2.9)</li>
<li>pyglet</li>
<li>numpy (for 3D view)</li>
<li>pycairo (to use Projector feature)</li>
<li>cairosvg (to use Projector feature)</li>
<li>dbus (to inhibit sleep on some Linux systems)</li>
</ul>

<p>Please see specific instructions for Windows and Mac OS X below. Under Linux, you should use your package manager directly (see the "GETTING PRINTRUN" section), or pip:</p>

<p><code>pip install -r requirements.txt</code></p>

<h3><a id="user-content-cython-based-g-code-parser" class="anchor" href="#cython-based-g-code-parser" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Cython-based G-Code parser</h3>

<p>Printrun default G-Code parser is quite memory hungry, but we also provide a much lighter one which just needs an extra build-time dependency (Cython), plus compiling the extension with:</p>

<pre><code>python setup.py build_ext --inplace
</code></pre>

<p>The warning message</p>

<pre><code>WARNING:root:Memory-efficient GCoder implementation unavailable: No module named gcoder_line
</code></pre>

<p>means that this optimized G-Code parser hasn't been compiled. To get rid of it and benefit from the better implementation, please install Cython and run the command above.</p>

<h3><a id="user-content-windows-1" class="anchor" href="#windows-1" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Windows</h3>

<p>Download the following, and install in this order:</p>

<ol>
<li><a href="http://python.org/ftp/python/2.7.2/python-2.7.2.msi">http://python.org/ftp/python/2.7.2/python-2.7.2.msi</a></li>
<li><a href="http://pypi.python.org/packages/any/p/pyserial/pyserial-2.5.win32.exe">http://pypi.python.org/packages/any/p/pyserial/pyserial-2.5.win32.exe</a></li>
<li><a href="http://downloads.sourceforge.net/wxpython/wxPython2.8-win32-unicode-2.8.12.0-py27.exe">http://downloads.sourceforge.net/wxpython/wxPython2.8-win32-unicode-2.8.12.0-py27.exe</a></li>
<li><a href="https://pypi.python.org/packages/any/p/pyreadline/pyreadline-1.7.1.win32.exe">https://pypi.python.org/packages/any/p/pyreadline/pyreadline-1.7.1.win32.exe</a></li>
<li><a href="http://pyglet.googlecode.com/files/pyglet-1.1.4.zip">http://pyglet.googlecode.com/files/pyglet-1.1.4.zip</a></li>
</ol>

<p>For the last one, you will need to unpack it, open a command terminal, 
go into the the directory you unpacked it in and run
<code>python setup.py install</code></p>

<h3><a id="user-content-mac-os-x-lion" class="anchor" href="#mac-os-x-lion" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Mac OS X Lion</h3>

<ol>
<li>Ensure that the active Python is the system version. (<code>brew uninstall python</code> or other appropriate incantations)</li>
<li>Download an install [wxPython2.8-osx-unicode] matching to your python version (most likely 2.7 on Lion, 
    check with: python --version) from: <a href="http://wxpython.org/download.php#stable">http://wxpython.org/download.php#stable</a>
Known to work PythonWX: <a href="http://superb-sea2.dl.sourceforge.net/project/wxpython/wxPython/2.8.12.1/wxPython2.8-osx-unicode-2.8.12.1-universal-py2.7.dmg">http://superb-sea2.dl.sourceforge.net/project/wxpython/wxPython/2.8.12.1/wxPython2.8-osx-unicode-2.8.12.1-universal-py2.7.dmg</a></li>
<li>Download and unpack pyserial from <a href="http://pypi.python.org/packages/source/p/pyserial/pyserial-2.5.tar.gz">http://pypi.python.org/packages/source/p/pyserial/pyserial-2.5.tar.gz</a></li>
<li>In a terminal, change to the folder you unzipped to, then type in: <code>sudo python setup.py install</code></li>
<li>Repeat 4. with http://<a href="http://pyglet.googlecode.com/files/pyglet-1.1.4.zip">http://pyglet.googlecode.com/files/pyglet-1.1.4.zip</a></li>
</ol>

<p>The tools will probably run just fine in 64bit on Lion, you don't need to mess
with any of the 32bit settings. In case they don't, try </p>

<ol>
<li>export VERSIONER_PYTHON_PREFER_32_BIT=yes
in a terminal before running Pronterface</li>
</ol>

<h3><a id="user-content-mac-os-x-pre-lion" class="anchor" href="#mac-os-x-pre-lion" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Mac OS X (pre Lion)</h3>

<p>A precompiled version is available at <a href="http://koti.kapsi.fi/%7Ekliment/printrun/">http://koti.kapsi.fi/~kliment/printrun/</a></p>

<ol>
<li>Download and install <a href="http://downloads.sourceforge.net/wxpython/wxPython2.8-osx-unicode-2.8.12.0-universal-py2.6.dmg">http://downloads.sourceforge.net/wxpython/wxPython2.8-osx-unicode-2.8.12.0-universal-py2.6.dmg</a></li>
<li>Grab the source for pyserial from <a href="http://pypi.python.org/packages/source/p/pyserial/pyserial-2.5.tar.gz">http://pypi.python.org/packages/source/p/pyserial/pyserial-2.5.tar.gz</a></li>
<li><p>Unzip pyserial to a folder. Then, in a terminal, change to the folder you unzipped to, then type in:</p>

<p><code>defaults write com.apple.versioner.python Prefer-32-Bit -bool yes</code></p>

<p><code>sudo python setup.py install</code></p></li>
</ol>

<p>Alternatively, you can run python in 32 bit mode by setting the following environment variable before running the setup.py command:</p>

<p>This alternative approach is confirmed to work on Mac OS X 10.6.8. </p>

<p><code>export VERSIONER_PYTHON_PREFER_32_BIT=yes</code></p>

<p><code>sudo python setup.py install</code></p>

<p>Then repeat the same with http://<a href="http://pyglet.googlecode.com/files/pyglet-1.1.4.zip">http://pyglet.googlecode.com/files/pyglet-1.1.4.zip</a></p>

<h1><a id="user-content-using-printrun" class="anchor" href="#using-printrun" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>USING PRINTRUN</h1>

<h2><a id="user-content-using-pronterface" class="anchor" href="#using-pronterface" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>USING PRONTERFACE</h2>

<p>When you're done setting up Printrun, you can start pronterface.py in the directory you unpacked it.
Select the port name you are using from the first drop-down, select your baud rate, and hit connect.
Load an STL (see the note on skeinforge below) or GCODE file, and you can upload it to SD or print it directly.
The "monitor printer" function, when enabled, checks the printer state (temperatures, SD print progress) every 3 seconds.
The command box recognizes all pronsole commands, but has no tabcompletion.</p>

<p>If you want to load stl files, you need to install a slicing program such as Slic3r and add its path to the settings.
See the Slic3r readme for more details on integration.</p>

<h2><a id="user-content-using-pronsole" class="anchor" href="#using-pronsole" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>USING PRONSOLE</h2>

<p>To use pronsole, you need:</p>

<ul>
<li>python (ideally 2.6.x or 2.7.x),</li>
<li>pyserial (or python-serial on ubuntu/debian) and</li>
<li>pyreadline (not needed on Linux)</li>
</ul>

<p>Start pronsole and you will be greeted with a command prompt. Type help to view the available commands.
All commands have internal help, which you can access by typing "help commandname", for example "help connect"</p>

<p>If you want to load stl files, you need to put a version of skeinforge (doesn't matter which one) in a folder called "skeinforge".
The "skeinforge" folder must be in the same folder as pronsole.py</p>

<h2><a id="user-content-using-printcore" class="anchor" href="#using-printcore" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>USING PRINTCORE</h2>

<p>To use printcore you need python (ideally 2.6.x or 2.7.x) and pyserial (or python-serial on ubuntu/debian)
See pronsole for an example of a full-featured host, the bottom of printcore.py for a simple command-line
sender, or the following code example:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c">#to send a file of gcode to the printer</span>
<span class="pl-k">from</span> printrun.printcore <span class="pl-k">import</span> printcore
<span class="pl-k">from</span> printrun <span class="pl-k">import</span> gcoder
p<span class="pl-k">=</span>printcore(<span class="pl-s"><span class="pl-pds">'</span>/dev/ttyUSB0<span class="pl-pds">'</span></span>,<span class="pl-c1">115200</span>) <span class="pl-c"># or p.printcore('COM3',115200) on Windows</span>
gcode<span class="pl-k">=</span>[i.strip() <span class="pl-k">for</span> i <span class="pl-k">in</span> <span class="pl-c1">open</span>(<span class="pl-s"><span class="pl-pds">'</span>filename.gcode<span class="pl-pds">'</span></span>)] <span class="pl-c"># or pass in your own array of gcode lines instead of reading from a file</span>
gcode <span class="pl-k">=</span> gcoder.LightGCode(gcode)
p.startprint(gcode) <span class="pl-c"># this will start a print</span>

<span class="pl-c">#If you need to interact with the printer:</span>
p.send_now(<span class="pl-s"><span class="pl-pds">"</span>M105<span class="pl-pds">"</span></span>) <span class="pl-c"># this will send M105 immediately, ahead of the rest of the print</span>
p.pause() <span class="pl-c"># use these to pause/resume the current print</span>
p.resume()
p.disconnect() <span class="pl-c"># this is how you disconnect from the printer once you are done. This will also stop running prints.</span></pre></div>

<h2><a id="user-content-platers" class="anchor" href="#platers" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>PLATERS</h2>

<p>Printrun provides two platers: a STL plater (<code>plater.py</code>) and a G-Code plater (<code>gcodeplater.py</code>).</p>

<h2><a id="user-content-3d-viewer-controls" class="anchor" href="#3d-viewer-controls" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>3D VIEWER CONTROLS</h2>

<p>When the 3D viewer is enabled, the controls are the following:</p>

<ul>
<li>Mousewheel: zoom (Control reduces the zoom change steps)</li>
<li>Shift+mousewheel: explore layers (in print gcode view ; Control key makes layer change by increments of 10 instead of 1) or rotate object (in platers)</li>
<li>Left-click dragging: rotate view</li>
<li>Right-click dragging: pan view</li>
<li>Shift + left-click dragging: move object (in platers)</li>
<li>Page up/down keys: zoom (Control reduces the zoom change steps)</li>
<li>Up/down keys: explore layers</li>
<li>R key: reset view</li>
<li>F key: fit view to display entire print</li>
<li>C key: toggle "display current layer only" mode (in print gcode view)</li>
</ul>

<h2><a id="user-content-rpc-server" class="anchor" href="#rpc-server" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>RPC SERVER</h2>

<p><code>pronterface</code> and <code>pronsole</code> start a RPC server, which runs by default
on localhost port 7978, which provides print progress information.
Here is a sample Python script querying the print status:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-k">import</span> xmlrpclib

rpc <span class="pl-k">=</span> xmlrpclib.ServerProxy(<span class="pl-s"><span class="pl-pds">'</span>http://localhost:7978<span class="pl-pds">'</span></span>)
<span class="pl-c1">print</span> rpc.status()</pre></div>

<h2><a id="user-content-configuration" class="anchor" href="#configuration" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>CONFIGURATION</h2>

<h3><a id="user-content-build-dimensions" class="anchor" href="#build-dimensions" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Build dimensions</h3>

<p>Build dimensions can be specified using the build_dimensions option (which can
be graphically edited in Pronterface settings). This option is formed of 9 parameters:
3 for the build volume dimensions, 3 for the build volume coordinate system
offset minimum, 3 for the endstop positions.</p>

<p>The default value is <code>200x200x100+0+0+0+0+0+0</code>, which corresponds to a
200x200mm (width x height) bed with 100mm travel in Z (there are the first
three numbers) and no offset. The absolute coordinates system origin (0,0,0) is
at the bottom left corner on the bed surface, and the top right corner on the
bed surface is (200,200,0).</p>

<p>A common practice is to have the origin of the coordinate system (0,0,0) at the
center of the bed surface. This is achieved by using the next three parameters,
for instance with <code>200x200x100-100-100+0+0+0+0</code>.
In this case, the bottom left corner of the bed will be at (-100,-100,0) and
the top right one at (100,100,0).</p>

<p>These two sets of settings should be sufficient for most people. However, for
some specific complicated setups and GCodes and some features, we might also
need the endstops positions for perfect display. These positions (which are
usually 0,0,0, so if you don't know you probably have a standard setup) are
specified in absolute coordinates, so if you have your bed starting at
(-100,-100,0) and your endstops are 10mm away from the bed left and right and
the Z endstop 5mm above the bed, you'll want to set the endstops positions to
(-110,-110,5) for this option.</p>

<h2><a id="user-content-using-macros-and-custom-buttons" class="anchor" href="#using-macros-and-custom-buttons" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>USING MACROS AND CUSTOM BUTTONS</h2>

<h3><a id="user-content-macros-in-pronsole-and-pronterface" class="anchor" href="#macros-in-pronsole-and-pronterface" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>Macros in pronsole and pronterface</h3>

<p>To send simple G-code (or pronsole command) sequence is as simple as entering them one by one in macro definition.
If you want to use parameters for your macros, substitute them with {0} {1} {2} ... etc.</p>

<p>All macros are saved automatically immediately after being entered.</p>

<p>Example 1, simple one-line alias:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro where <span class="pl-c1">M114</span></pre></div>

<p>Instead of having to remember the code to query position, you can query the position:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> where
<span class="pl-c1">X</span>:<span class="pl-c1">25.</span><span class="pl-ii">00Y</span>:<span class="pl-c1">11.</span><span class="pl-ii">43Z</span>:<span class="pl-c1">5.</span><span class="pl-ii">11E</span>:<span class="pl-c1">0.00</span></pre></div>

<p>Example 2 - macros to switch between different slicer programs, using "set" command to change options:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro use_slicer
Enter macro using indented lines, end <span class="pl-k">with</span> empty line
..<span class="pl-k">&gt;</span> <span class="pl-c1">set</span> sliceoptscommand Slic3r<span class="pl-k">/</span>slic3r.exe <span class="pl-ii">--</span>load slic3r.ini
..<span class="pl-k">&gt;</span> <span class="pl-c1">set</span> slicecommand Slic3r<span class="pl-k">/</span>slic3r.exe <span class="pl-ii">$</span>s <span class="pl-ii">--</span>load slic3r.ini <span class="pl-ii">--</span>output <span class="pl-ii">$</span>o
Macro <span class="pl-s"><span class="pl-pds">'</span>use_slicer<span class="pl-pds">'</span></span> defined
<span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro use_sfact
..<span class="pl-k">&gt;</span> <span class="pl-c1">set</span> sliceoptscommand python skeinforge<span class="pl-k">/</span>skeinforge_application<span class="pl-k">/</span>skeinforge.py
..<span class="pl-k">&gt;</span> <span class="pl-c1">set</span> slicecommand python skeinforge<span class="pl-k">/</span>skeinforge_application<span class="pl-k">/</span>skeinforge_utilities<span class="pl-k">/</span>skeinforge_craft.py <span class="pl-ii">$</span>s
Macro <span class="pl-s"><span class="pl-pds">'</span>use_sfact<span class="pl-pds">'</span></span> defined</pre></div>

<p>Example 3, simple parametric macro:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro move_down_by
Enter macro using indented lines, end <span class="pl-k">with</span> empty line
..<span class="pl-k">&gt;</span> <span class="pl-c1">G91</span>
..<span class="pl-k">&gt;</span> <span class="pl-c1">G1</span> <span class="pl-c1">Z</span><span class="pl-k">-</span>{<span class="pl-c1">0</span>}
..<span class="pl-k">&gt;</span> <span class="pl-c1">G92</span>
..<span class="pl-k">&gt;</span></pre></div>

<p>Invoke the macro to move the printhead down by 5 millimeters:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> move_down_by <span class="pl-c1">5</span></pre></div>

<p>For more powerful macro programming, it is possible to use python code escaping using ! symbol in front of macro commands.
Note that this python code invocation also works in interactive prompt:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> <span class="pl-ii">!</span><span class="pl-c1">print</span> <span class="pl-s"><span class="pl-pds">"</span>Hello, printer!<span class="pl-pds">"</span></span>
Hello printer!

<span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro debug_on <span class="pl-ii">!</span><span class="pl-v">self</span>.p.loud <span class="pl-k">=</span> <span class="pl-c1">1</span>
Macro <span class="pl-s"><span class="pl-pds">'</span>debug_on<span class="pl-pds">'</span></span> defined
<span class="pl-c1">PC</span><span class="pl-k">&gt;</span> debug_on
<span class="pl-c1">PC</span><span class="pl-k">&gt;</span> <span class="pl-c1">M114</span>
<span class="pl-c1">SENT</span>:  <span class="pl-c1">M114</span>
<span class="pl-c1">X</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Y</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Z</span>:<span class="pl-c1">0.</span><span class="pl-ii">00E</span>:<span class="pl-c1">0.00</span> Count <span class="pl-c1">X</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Y</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Z</span>:<span class="pl-c1">0.00</span>
<span class="pl-c1">RECV</span>:  <span class="pl-c1">X</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Y</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Z</span>:<span class="pl-c1">0.</span><span class="pl-ii">00E</span>:<span class="pl-c1">0.00</span> Count <span class="pl-c1">X</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Y</span>:<span class="pl-c1">0.</span><span class="pl-ii">00Z</span>:<span class="pl-c1">0.00</span>
<span class="pl-c1">RECV</span>:  ok</pre></div>

<p>You can use macro command itself to create simple self-modify or toggle functionality:</p>

<p>Example: swapping two macros to implement toggle:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro toggle_debug_on
Enter macro using indented lines, end <span class="pl-k">with</span> empty line
..<span class="pl-k">&gt;</span> <span class="pl-ii">!</span><span class="pl-v">self</span>.p.loud <span class="pl-k">=</span> <span class="pl-c1">1</span>
..<span class="pl-k">&gt;</span> <span class="pl-ii">!</span><span class="pl-c1">print</span> <span class="pl-s"><span class="pl-pds">"</span>Diagnostic information ON<span class="pl-pds">"</span></span>
..<span class="pl-k">&gt;</span> macro toggle_debug toggle_debug_off
..<span class="pl-k">&gt;</span>
Macro <span class="pl-s"><span class="pl-pds">'</span>toggle_debug_on<span class="pl-pds">'</span></span> defined
<span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro toggle_debug_off
Enter macro using indented lines, end <span class="pl-k">with</span> empty line
..<span class="pl-k">&gt;</span> <span class="pl-ii">!</span><span class="pl-v">self</span>.p.loud <span class="pl-k">=</span> <span class="pl-c1">0</span>
..<span class="pl-k">&gt;</span> <span class="pl-ii">!</span><span class="pl-c1">print</span> <span class="pl-s"><span class="pl-pds">"</span>Diagnostic information OFF<span class="pl-pds">"</span></span>
..<span class="pl-k">&gt;</span> macro toggle_debug toggle_debug_on
..<span class="pl-k">&gt;</span>
Macro <span class="pl-s"><span class="pl-pds">'</span>toggle_debug_off<span class="pl-pds">'</span></span> defined
<span class="pl-c1">PC</span><span class="pl-k">&gt;</span> macro toggle_debug toggle_debug_on
Macro <span class="pl-s"><span class="pl-pds">'</span>toggle_debug<span class="pl-pds">'</span></span> defined</pre></div>

<p>Now, each time we invoke "toggle_debug" macro, it toggles debug information on and off:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-c1">PC</span><span class="pl-k">&gt;</span> toggle_debug
Diagnostic information <span class="pl-c1">ON</span>

<span class="pl-c1">PC</span><span class="pl-k">&gt;</span> toggle_debug
Diagnostic information <span class="pl-c1">OFF</span></pre></div>

<p>When python code (using ! symbol) is used in macros, it is even possible to use blocks/conditionals/loops.
It is okay to mix python code with pronsole commands, just keep the python indentation.
For example, following macro toggles the diagnostic information similarily to the previous example:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-ii">!</span><span class="pl-k">if</span> <span class="pl-v">self</span>.p.loud:
  <span class="pl-ii">!</span><span class="pl-v">self</span>.p.loud <span class="pl-k">=</span> <span class="pl-c1">0</span>
  <span class="pl-ii">!</span><span class="pl-c1">print</span> <span class="pl-s"><span class="pl-pds">"</span>Diagnostic information OFF<span class="pl-pds">"</span></span>
<span class="pl-ii">!</span><span class="pl-k">else</span>:
  <span class="pl-ii">!</span><span class="pl-v">self</span>.p.loud <span class="pl-k">=</span> <span class="pl-c1">1</span>
  <span class="pl-ii">!</span><span class="pl-c1">print</span> <span class="pl-s"><span class="pl-pds">"</span>Diagnostic information ON<span class="pl-pds">"</span></span></pre></div>

<p>Macro parameters are available in '!'-escaped python code as locally defined list variable: arg[0] arg[1] ... arg[N]</p>

<p>All python code is executed in the context of the pronsole (or PronterWindow) object, 
so it is possible to use all internal variables and methods, which provide great deal of functionality.
However the internal variables and methods are not very well documented and may be subject of change, as the program is developed.
Therefore it is best to use pronsole commands, which easily contain majority of the functionality that might be needed.</p>

<p>Some useful python-mode-only variables:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-ii">!</span><span class="pl-v">self</span>.settings <span class="pl-k">-</span> contains <span class="pl-c1">all</span> settings, e.g. 
  port (<span class="pl-ii">!</span><span class="pl-v">self</span>.settings.port), baudrate, xy_feedrate, e_feedrate, slicecommand, final_command, build_dimensions
  You can <span class="pl-c1">set</span> them also via pronsole command <span class="pl-s"><span class="pl-pds">"</span>set<span class="pl-pds">"</span></span>, but you can query the values only via python code.
<span class="pl-ii">!</span><span class="pl-v">self</span>.p <span class="pl-k">-</span> printcore <span class="pl-c1">object</span> (see <span class="pl-c1">USING</span> <span class="pl-c1">PRINTCORE</span> section <span class="pl-k">for</span> using printcore <span class="pl-c1">object</span>)
<span class="pl-ii">!</span><span class="pl-v">self</span>.cur_button <span class="pl-k">-</span> <span class="pl-k">if</span> macro was invoked via custom button, the number of the custom button, e.g. <span class="pl-k">for</span> usage <span class="pl-k">in</span> <span class="pl-s"><span class="pl-pds">"</span>button<span class="pl-pds">"</span></span> command
<span class="pl-ii">!</span><span class="pl-v">self</span>.gwindow <span class="pl-k">-</span> wx graphical interface <span class="pl-c1">object</span> <span class="pl-k">for</span> pronterface (highly risky to use because the <span class="pl-c1">GUI</span> implementation details may change a lot between versions)</pre></div>

<p>Some useful methods:</p>

<div class="highlight highlight-source-python"><pre><span class="pl-ii">!</span><span class="pl-v">self</span>.onecmd <span class="pl-k">-</span> invokes raw command, e.g. 
    <span class="pl-ii">!</span><span class="pl-v">self</span>.onecmd(<span class="pl-s"><span class="pl-pds">"</span>move x 10<span class="pl-pds">"</span></span>)
    <span class="pl-ii">!</span><span class="pl-v">self</span>.onecmd(<span class="pl-s"><span class="pl-pds">"</span>!print self.p.loud<span class="pl-pds">"</span></span>)
    <span class="pl-ii">!</span><span class="pl-v">self</span>.onecmd(<span class="pl-s"><span class="pl-pds">"</span>button <span class="pl-pds">"</span></span><span class="pl-k">+</span><span class="pl-v">self</span>.cur_button<span class="pl-k">+</span><span class="pl-s"><span class="pl-pds">"</span> fanOFF /C cyan M107<span class="pl-pds">"</span></span>)
<span class="pl-ii">!</span><span class="pl-v">self</span>.project <span class="pl-k">-</span> invoke Projector</pre></div>

<h2><a id="user-content-using-host-commands" class="anchor" href="#using-host-commands" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>USING HOST COMMANDS</h2>

<p>Pronsole and the console interface in Pronterface accept a number of commands
which you can either use directly or inside your G-Code. To run a host command
from inside a G-Code, simply prefix it with <code>;@</code>.</p>

<p>List of available commands:</p>

<ul>
<li><code>pause</code>: pauses the print until the user resumes it</li>
<li><code>run_script scriptname [arg1 ...]</code>: runs a custom script or program on the
host computer. This can for instance be used to produce a sound to warn the
user (e.g. <code>run_script beep -r 2</code> on machines were the <code>beep</code> util is
available), or to send an email or text message at the end of a print. The $s
token can be used in the arguments to get the current gcode file name</li>
<li><code>run_gcode_script scripname [arg1 ...]</code>: same as <code>run_script</code>, except that
all lines displayed by the script will be interpreted in turn (so that G-Code
lines will be immediately sent to the printer)</li>
<li><code>shell pythoncommand</code>: run a python command (can also be achieved by doing
<code>!pythoncommand</code>)</li>
<li><code>set option value</code>: sets the value of an option, e.g. <code>set mainviz 3D</code></li>
<li><code>connect</code></li>
<li><code>block_until_online</code>: wait for the printer to be online. For instance you can
do <code>python pronsole.py -e "connect" -e "block_until_online" -e "upload
object.gcode"</code> to start pronsole, connect for the printer, wait for it to be
online to start uploading the <code>object.gcode</code> file.</li>
<li><code>disconnect</code></li>
<li><code>load gcodefile</code></li>
<li><code>upload gcodefile target.g</code>: upload <code>gcodefile</code> to <code>target.g</code> on the SD card</li>
<li><code>slice stlfile</code>: slice <code>stlfile</code> and load the produced G-Code</li>
<li><code>print</code>: print the currently loaded file</li>
<li><code>sdprint target.g</code>: start a SD print</li>
<li><code>ls</code>: list files on SD card</li>
<li><code>eta</code>: display remaining print time</li>
<li><code>gettemp</code>: get current printer temperatures</li>
<li><code>settemp</code>: set hotend target temperature</li>
<li><code>bedtemp</code>: set bed target temperature</li>
<li><code>monitor</code>: monitor printer progress during a print</li>
<li><code>tool K</code>: switch to tool K</li>
<li><code>move xK</code>: move along <code>x</code> axis (works with other axes too)</li>
<li><code>extrude length [speed]</code></li>
<li><code>reverse length [speed]</code></li>
<li><code>home [axis]</code></li>
<li><code>off</code>: turns off fans, motors, extruder, heatbed, power supply</li>
<li><code>exit</code></li>
</ul>

<h1><a id="user-content-license" class="anchor" href="#license" aria-hidden="true"><svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M4 9h1v1h-1c-1.5 0-3-1.69-3-3.5s1.55-3.5 3-3.5h4c1.45 0 3 1.69 3 3.5 0 1.41-0.91 2.72-2 3.25v-1.16c0.58-0.45 1-1.27 1-2.09 0-1.28-1.02-2.5-2-2.5H4c-0.98 0-2 1.22-2 2.5s1 2.5 2 2.5z m9-3h-1v1h1c1 0 2 1.22 2 2.5s-1.02 2.5-2 2.5H9c-0.98 0-2-1.22-2-2.5 0-0.83 0.42-1.64 1-2.09v-1.16c-1.09 0.53-2 1.84-2 3.25 0 1.81 1.55 3.5 3 3.5h4c1.45 0 3-1.69 3-3.5s-1.5-3.5-3-3.5z"></path></svg></a>LICENSE</h1>

<pre><code>Printrun is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Printrun is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Printrun.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
</code></pre>

<p>All scripts should contain this license note, if not, feel free to ask us. Please note that files where it is difficult to state this license note (such as images) are distributed under the same terms.</p>
</article>
  </div>

</div>

<button type="button" data-facebox="#jump-to-line" data-facebox-class="linejump" data-hotkey="l" class="hidden">Jump to Line</button>
<div id="jump-to-line" style="display:none">
  <!-- </textarea> --><!-- '"` --><form accept-charset="UTF-8" action="" class="js-jump-to-line-form" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
    <input class="form-control linejump-input js-jump-to-line-field" type="text" placeholder="Jump to line&hellip;" aria-label="Jump to line" autofocus>
    <button type="submit" class="btn">Go</button>
</form></div>

  </div>
  <div class="modal-backdrop"></div>
</div>


    </div>
  </div>

    </div>

        <div class="container site-footer-container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage" class="site-footer-mark" title="GitHub">
      <svg aria-hidden="true" class="octicon octicon-mark-github" height="24" version="1.1" viewBox="0 0 16 16" width="24"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59 0.4 0.07 0.55-0.17 0.55-0.38 0-0.19-0.01-0.82-0.01-1.49-2.01 0.37-2.53-0.49-2.69-0.94-0.09-0.23-0.48-0.94-0.82-1.13-0.28-0.15-0.68-0.52-0.01-0.53 0.63-0.01 1.08 0.58 1.23 0.82 0.72 1.21 1.87 0.87 2.33 0.66 0.07-0.52 0.28-0.87 0.51-1.07-1.78-0.2-3.64-0.89-3.64-3.95 0-0.87 0.31-1.59 0.82-2.15-0.08-0.2-0.36-1.02 0.08-2.12 0 0 0.67-0.21 2.2 0.82 0.64-0.18 1.32-0.27 2-0.27 0.68 0 1.36 0.09 2 0.27 1.53-1.04 2.2-0.82 2.2-0.82 0.44 1.1 0.16 1.92 0.08 2.12 0.51 0.56 0.82 1.27 0.82 2.15 0 3.07-1.87 3.75-3.65 3.95 0.29 0.25 0.54 0.73 0.54 1.48 0 1.07-0.01 1.93-0.01 2.2 0 0.21 0.15 0.46 0.55 0.38C13.71 14.53 16 11.53 16 8 16 3.58 12.42 0 8 0z"></path></svg>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2016 <span title="0.05015s from github-fe128-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
        <li><a href="https://help.github.com" data-ga-click="Footer, go to help, text:help">Help</a></li>
    </ul>
  </div>
</div>



    

    <div id="ajax-error-message" class="ajax-error-message flash flash-error">
      <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M15.72 12.5l-6.85-11.98C8.69 0.21 8.36 0.02 8 0.02s-0.69 0.19-0.87 0.5l-6.85 11.98c-0.18 0.31-0.18 0.69 0 1C0.47 13.81 0.8 14 1.15 14h13.7c0.36 0 0.69-0.19 0.86-0.5S15.89 12.81 15.72 12.5zM9 12H7V10h2V12zM9 9H7V5h2V9z"></path></svg>
      <button type="button" class="flash-close js-flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
        <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M7.48 8l3.75 3.75-1.48 1.48-3.75-3.75-3.75 3.75-1.48-1.48 3.75-3.75L0.77 4.25l1.48-1.48 3.75 3.75 3.75-3.75 1.48 1.48-3.75 3.75z"></path></svg>
      </button>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/compat-7db58f8b7b91111107fac755dd8b178fe7db0f209ced51fc339c446ad3f8da2b.js"></script>
      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-f8175c23360b42a4eb18b2319fefeae252cfeea482fb804356f4136a52bfddb3.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github-1502104f450cb05859f99b57e29782e071e3fb240e237adb8cbf17ebbdb271c7.js"></script>
      
      
      
      
      
      
    <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner hidden">
      <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path d="M15.72 12.5l-6.85-11.98C8.69 0.21 8.36 0.02 8 0.02s-0.69 0.19-0.87 0.5l-6.85 11.98c-0.18 0.31-0.18 0.69 0 1C0.47 13.81 0.8 14 1.15 14h13.7c0.36 0 0.69-0.19 0.86-0.5S15.89 12.81 15.72 12.5zM9 12H7V10h2V12zM9 9H7V5h2V9z"></path></svg>
      <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
      <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
    </div>
    <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M7.48 8l3.75 3.75-1.48 1.48-3.75-3.75-3.75 3.75-1.48-1.48 3.75-3.75L0.77 4.25l1.48-1.48 3.75 3.75 3.75-3.75 1.48 1.48-3.75 3.75z"></path></svg>
    </button>
  </div>
</div>

  </body>
</html>

