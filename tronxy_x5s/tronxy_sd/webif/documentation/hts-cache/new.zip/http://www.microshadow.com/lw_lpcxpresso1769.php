<html>
<head>
<title>LadderWORK for LPCXpresso 1769</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="EXPIRES" content="0">
<meta name="RESOURCE-TYPE" content="DOCUMENT">
<meta name="KEYWORDS" content="LadderWORK for LPCXpresso 1769">
<meta name="DESCRIPTION" content="MicroSHADOW">
<meta name="ROBOTS" content="INDEX, FOLLOW">
<meta name="REVISIT-AFTER" content="1 DAYS">
<meta name="RATING" content="GENERAL">
<link rel="stylesheet" href="default.css" type="text/css">
</head>


<body bgcolor="3B425F" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#C0C0C0" vlink="#C0C0C0" alink="#C0C0C0">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="95%" >
  <tr>
    <td valign="top" align="center">
      <table width="780" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#808080">
        <tr> 
          <td valign="top" align="center" colspan="2">
              <hr>
					<p class="testobasso">
						LadderWORK for LPCXpresso 1769
					</p>
              <hr>
		  </td>
        </tr>
        <tr> 
          <td valign="top" colspan="2"><img src="img/head_001.gif" width="780" height="197" usemap="#head_001_Map" border="0"></td>
        </tr>

        <tr> 
          <td bgcolor="#808080">&nbsp;</td>
		  <td bgcolor="#808080">
		  <p class="testodinam" align="center">
		  <font size=1>
		  |<a href="index.php">Home</a>
		  |<a href="compinfo.php">Company Info</a>
		  |<a href="products.php">Products</a>
		  |<a href="order.php">Prices&Order</a>
		  |<a href="techsprt.php">Tech Support</a>
		  |<a href="partners.php">Partners</a>
		  |<a href="page8051.php">8051 Page</a>
		  |<a href="hotlinks.php">Hot Links</a>
		  |
		  </p>
		  </td>
        </tr>

        <tr> 
          <!-- LEFT COLUMN -->
          <td width="188" valign="top"> 
			<table width="100%" cellspacing="8">

			<tr>
			<td bgcolor="#808080">
            
			</td>
			</tr>

			<tr>
			<td bgcolor="#808080">
            
			</td>
			</tr>

			<tr>
			<td bgcolor="#808080">
            
			</td>
			</tr>

			<tr>
			<td bgcolor="#808080">
            
			</td>
			</tr>

			<tr>
			<td bgcolor="#808080">
            
			</td>
			</tr>

			<!-- <tr>
			<td bgcolor="#000000" valign="bottom" height="400">
			</td>
			</tr> -->

			</table>
          </td>
          <!-- LEFT COLUMN -->
          <td width="623" align="center" valign="top" bgcolor="#FFFFFF" rowspan="2"> 
            
<!-- START E:\TheWeb\Site2005\sources\areas\lw_lpcxpresso1769.htm -->
<style type="text/css">
<!--

A.download:link     { color: #000000; text-decoration: none; }
A.download:visited  { color: #000000; text-decoration: none; }
A.download:hover    { color: #008080; text-decoration: underline; }

-->
</style>

<link rel="stylesheet" href="default.css" type="text/css">




<table width="560" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td width="100%" height="12">
		&nbsp;
	</td>
</tr>
<tr>
	<td width="100%">
		<p class="testodinam" align="center"><font size=+1><b>Embedded Artists LPCXpresso LPC1769</b></p>
	</td>
</tr>
	<td width="100%" height="12">
		&nbsp;
	</td>
</table>




<p align="center">&nbsp;</p>
<table width="100%" height="2094" border="0" cellpadding="4" cellspacing="0">
  <tr> 
    <td valign="middle">
<div align="center"><img src="img/products/ea/ea_logo1.jpg" width="300" height="186"></div></td>
    <td valign="middle">
<div align="center"><img src="img/products/ea/ea_lpcxpresso1769_a.jpg" width="400" height="200"></div></td>
  </tr>
  <tr> 
    <td width="44%" valign="top">&nbsp;</td>
    <td width="56%" valign="top"> <table width="100%" border="0" cellpadding="0" cellspacing="8" bordercolor="#000000" class="testodinam">
        <tr> 
          <td colspan="2" valign="top"><strong>Quick page links:</strong></td>
        </tr>
        <tr> 
          <td width="12%" align="left" valign="top"> <img src="img/bullet.jpg"></td>
          <td width="88%"><a href="#lpcxpresso_overview">LPCXpresso Overview</a></td>
        </tr>
        <tr> 
          <td align="left" valign="top"><img src="img/bullet.jpg"></td>
          <td><a href="#ladderwork_overview">LadderWORK Overview</a></td>
        </tr>
        <tr> 
          <td align="left" valign="top"> <img src="img/bullet.jpg" width="28" height="11"></td>
          <td><a href="#ladderwork_ide">The Integrated Development environment 
            (IDE)</a></td>
        </tr>
        <tr> 
          <td align="left" valign="top"><img src="img/bullet.jpg" width="28" height="11"></td>
          <td><a href="#related_documents">Download section and related documents</a></td>
        </tr>
        <tr> 
          <td align="left" valign="top"><img src="img/bullet.jpg" width="28" height="11"></td>
          <td><a href="http://www.microshadow.com/support/htmldocs/ladderwork/main_index.htm">LadderWORK's 
            On-Line Manual</a></td>
        </tr>
        <tr>
          <td valign="top"><img src="img/bullet.jpg" width="28" height="11"></td>
          <td><a href="http://www.microshadow.com/support/htmldocs/ladderwork/tutorial.htm">LadderWORK Tutorial (Start here to get some basic concepts)</a></td>
        </tr>
        <tr> 
          <td valign="top"><img src="img/bullet.jpg" width="28" height="11"></td>
          <td><a href="wouldyoubuild.php">Would you build a programmable logic 
            controller (PLC) supported by LadderWORK? Click Here</a></td>
        </tr>
        <tr> 
          <td valign="top"> <div align="right"></div></td>
          <td>&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td height="530" colspan="2"> 
      <p class="testodinam" align="left"><b><font size=+1><a name="lpcxpresso_overview"></a>LPCXpresso 
        Overview</font></b> 
      <p class="testodinam" align="left">&nbsp; 
      <p class="testodinam" align="left">LPCXpresso 1769 is a new, low-cost development 
        system available from Embedded Artists. Designed for simplicity and ease 
        of use, the LPCXpresso provides software engineers a quick and easy way 
        to develop their applications from initial evaluation to final production. 
        The LPCXpresso target board is jointly developed by Embedded Artists, 
        Code Red, and NXP. The target board, based on the NXP LPC1769 chip, is 
        supported by MicroSHADOW Research's LadderWORK software. The software 
        is available in a free demo version allowing to to have a complete tour 
        in the simplicity of the graphical programming. 
      <p class="testodinam" align="left">For further informations about LPCXpresso 
        click here &lt;<a href="http://www.embeddedartists.com/products/lpcxpresso">http://www.embeddedartists.com/products/lpcxpresso</a> 
        &gt;
      <p class="testodinam" align="left"><font size="+1">LadderWORK Overview<a name="ladderwork_overview"></a></font> 
      <p class="testodinam" align="left">LadderWORK is the easiest way to create 
        automation control programs. Use of LadderWORK is immediate. With the 
        use of the mouse only, you simply place functional objects in your worksheet 
        , connect the components with wires and configure the components property. 
        Microprocessor assembler code will be generated at the simply push of 
        the BUILD button.&nbsp; <br>
        LadderWORK software integrate a powerful schematic editor with multi view 
        feature and context-sensitive help.&nbsp; <br>
        LadderWORK's generated code is really efficent. Microprocessor's assembly 
        code it's directly generated by the compiler so no other instructions 
        charge will affect your result ( NO 'C' SOURCE GENERATED AND COMPILED 
        PROCESS ). In this way with LadderWORK you always are sure to obtain the 
        best size &amp; speed optimized code.&nbsp; <br>
        LadderWORK produce a Intel-Std HEX file as output. Also intermediate assembler 
        and listing files are available as output of LadderWORK compile process 
        so you can check instruction by instruction the generated code. Many PLC 
        devices supported by LadderWORK software can directly upload the generated 
        code simply pushing the UPLOAD button. A great number of build-in functional 
        components are ready to be placed in your project. LadderWORK software 
        includes a standard set of LADDER DIAGRAM (RELAY LOGIC) devices and a 
        set of extra components, like pure-logical ports and user-programmable 
        functions.&nbsp; <br>
        Full ADVANCED version includes over 30 devices : input/output devices, 
        relays, d-type flip flops, debouncers, clock generators, delay lines, 
        up/down counters, comparators, fifo/lifo queues, A/D &amp; D/A converters, 
        and/or/not logical ports and user programmable functions.LadderWORK produce 
        a Intel-Std HEX file as output. Also intermediate assembler and listing 
        files are available as output of LadderWORK compile process so you can 
        check instruction by instruction the generated code. Many PLC devices 
        supported by LadderWORK software can directly upload the generated code 
        simply pushing the UPLOAD button. </td>
    <td width="0"><font size="1">&nbsp;</font></td>
  </tr>
  <tr> 
    <td colspan="2" valign="top">
<p class="testodinam" align="left"><b><font size=+1>More than a Ladder language</font></b> 
      <p class="testodinam" align="left">Ladder standard language is strongly 
        rigid. Components must be forced in predeterminated cells along two rails 
        called rungs. Moreover Ladder standard language has great limitations 
        about feedback connections. LadderWORK broken these limitations introducing 
        the first free schematic ladder diagram. LadderWORK includes a powerful 
        schematic editor. Components can be placed anywhere and there isn't limitation 
        on feedback connections. LadderWORK schematic is more similar to an electrical 
        circuit. Moreover LadderWORK includes extra components like logical ports 
        and flip-flops so if you are well-versed in boolean logic you can approach 
        your problem using these traditional notation. 
      <p class="testodinam" align="left"><b><font size=+1>Electrical notation 
        approach</font></b> 
      <p class="testodinam" align="left"><strong>LadderWORK is remarkably intuitive!</strong>
      <p class="testodinam" align="left"><br>
        With LadderWORK you haven't to know nothing about assembler, interrupts 
        or hardware architectures. All you have to do is think your project as 
        a electrical scheme where you have to disposition switches, relays and 
        lamps. Switches means inputs, lamps means outputs and relays gives the 
        way to create states and elementary memory cells. Many problems related 
        to control automation can be resolved in few minutes using LadderWORK.
      <p class="testodinam" align="left"><strong>Put a PLC into your microcontroller!</strong> 
      <p class="testodinam" align="left">With LadderWORK you can transfom a microcontroller 
        in a full-featured PLC. LadderWORK and LPCXpresso gives you a way to try 
        this amazing system. You can have a working PLC few minutes and, as you 
        can see, just using a microcontroller and few other components.
      <p class="testodinam" align="left"><br>
        <a name="ladderwork_ide"></a> <font size=+1><b>The LadderWORK Integrated 
        Development Environment (IDE)</b></font> 
      <p class="testodinam" align="left"> The picture below, represents the apperance 
        of the program LadderWORK on your computer. LadderWORK has an integrated 
        environment feature, allowing you to draw schematics, compile programs 
        and upload code to PLC always working on the same window. The integrated 
        environments are composed by several parts described below.<br>
        <br>
      <p class="testodinam" align="left"> 
        <center>
          <p><a href="img/products/ladderwork_lpcxpresso/ide_full.jpg"><img src="img/products/ladderwork_lpcxpresso/ide_reduced.jpg" width="600" height="328"></a> 
          </p>
          
        <p class="testodinam" align="center"><a href="img/products/ladderwork_lpcxpresso/ide_full.jpg">Click on the image, or here, for 
          a high-res picture</a></p>
        </center>
      <p class="testodinam" align="left"><strong><a name="related_documents"></a>Related 
        Documents and files</strong> 
      <p class="testodinam" align="left"> 
        


<table width="100%" border="1" cellspacing="0" cellpadding="4" align="center">

<tr bgcolor="#C0C0C0"> 
<td width="20%" class="testodinam"><b>File Name</b></td>
<td width="70%" class="testodinam"><b>Description</b></td>
<td width="10%" class="testodinam"><b>Size</b></td> 
</tr>

<tr bgcolor="#FFFFFF"><td width="20%" valign="top" class="testodinam"><a href="files/software/package_ea_20120203.rar"><font color="#000000">package_ea_20120203.rar</font></a></td><td width="70%" valign="top" class="testodinam">LadderWORK for LPCXpresso</td><td width="10%" valign="top" class="testodinam">20Mb</td></tr>
</table>      <p></p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    <td></td>
  </tr>
</table>
<p>&nbsp;</p>
<p class="testodinam" align="left"><b></b></p>
<p class="testodinam" align="left">&nbsp; </p>


<!-- END file E:\TheWeb\Site2005\sources\areas\lw_lpcxpresso1769.htm -->

          </td>
        </tr>
        <tr> 
          <td valign="bottom" bgcolor="#808080">
		    <a href="contactus.php">
			<img src="img/contactus.jpg" border="0">
			</a>
		  </td>
          <!-- 
		  Commentare quando area1 rowspan="2"
		  <td valign="bottom" bgcolor="#000000">&nbsp;</td> -->
        </tr>
        <tr> 
          <td bgcolor="3F555B">&nbsp;</td>
          <td bgcolor="3F555B">&nbsp;</td>
        </tr>
        <tr> 
          <td bgcolor="191B1B">&nbsp;</td>
          <td bgcolor="191B1B">
            
<!-- START E:\TheWeb\Site2005\sources\include\copyright.inc -->
<div align="center">
<p class="testobasso">Send your comments and suggestions about this 
web site to <a href="mailto:webmaster@microshadow.com"><font color="#333333">webmaster@microshadow.com 
</font></a><br>
Copyright &copy; 1997-2012 MicroSHADOW Research<br>
Page updated in February, 2012 (C)CopyRight 1997-2012 MicroSHADOW Research (uS) - All rights reserved<br>
PIVA/VAT/BTW code IT00591950456
</p>

<!-- END file E:\TheWeb\Site2005\sources\include\copyright.inc -->

          </td>
        </tr>

		<!-- Counter and stats  -->
		<tr>
		</tr>
		<!-- Counter and stats -->

      </table>
    </td>
  </tr>
</table>


<!-- START E:\TheWeb\Site2005\sources\include\buttonmap.inc -->
<MAP NAME="head_001_Map">
<AREA SHAPE="rect" ALT="" COORDS="31,8,205,150" HREF="index.php">
<AREA SHAPE="rect" ALT="" COORDS="197,169,282,195" HREF="compinfo.php">
<AREA SHAPE="rect" ALT="" COORDS="284,169,351,195" HREF="products.php">
<AREA SHAPE="rect" ALT="" COORDS="352,169,454,195" HREF="order.php">
<AREA SHAPE="rect" ALT="" COORDS="622,169,698,195" HREF="page8051.php">
<AREA SHAPE="rect" ALT="" COORDS="550,169,618,195" HREF="partners.php">
<AREA SHAPE="rect" ALT="" COORDS="455,168,547,194" HREF="techsprt.php">
<AREA SHAPE="rect" ALT="" COORDS="703,169,774,195" HREF="hotlinks.php">
<AREA SHAPE="rect" ALT="" COORDS="2,168,49,194" HREF="index.php">
</MAP>

<!-- END file E:\TheWeb\Site2005\sources\include\buttonmap.inc -->

</body>
</html>

