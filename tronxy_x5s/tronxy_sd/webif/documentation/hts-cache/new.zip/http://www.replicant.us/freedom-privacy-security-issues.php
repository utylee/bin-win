<!DOCTYPE html>

<html lang="en">

<head>
	<meta charset="utf-8" />

	<title>Replicant</title>

	<link rel="shortcut icon" href="images/replicant_icon.png" type="image/png" />

	<link rel="stylesheet" href="css/bootstrap.css" />
	<link rel="stylesheet" href="css/bootstrap-theme.css" />
	<link rel="stylesheet" href="css/equal-height-columns.css" />
	<link rel="stylesheet" href="css/replicant.css" />

	<link rel="stylesheet" href="css/lightbox.css" />
</head>

<body role="document">

<div class="navbar navbar-inverse" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="/"><img src="images/replicant_navigation.png" alt="Replicant" /></a>
		</div>
		<div class="navbar-collapse collapse">
			<ul class="nav navbar-nav">
				<li><a href="//blog.replicant.us/">Blog</a></li>
				<li><a href="//redmine.replicant.us/projects/replicant/wiki">Wiki</a></li>
				<li><a href="//redmine.replicant.us/projects/replicant/issues">Tracker</a></li>
				<li><a href="//redmine.replicant.us/projects/replicant/boards">Forums</a></li>
			</ul>
		</div>
	</div>
</div>

<div class="jumbotron">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<div class="text-left"><a href="/"><img src="images/replicant.png" alt="Replicant" class="img-responsive" /></a></div>
				<p>Replicant is a fully free Android distribution running on several devices,<br /><small>a free software mobile operating system putting the emphasis on freedom and privacy/security</small></p>

				<div class="btn-group" style="margin-top: 20px;">
					<a href="about.php" class="btn btn-primary" role="button"><span class="glyphicon glyphicon-book"></span> About</a>
					<a href="about.php#faq" class="btn btn-default" role="button">FAQ</a>
					<a href="freedom-privacy-security-issues.php" class="btn btn-default" role="button">Freedom and privacy/security</a>
					<a href="freedom-privacy-security-issues.php#recommendations" class="btn btn-default" role="button">Recommendations</a>
					<a href="supported-devices.php" class="btn btn-default" role="button"><span class="glyphicon glyphicon-phone"></span> Devices</a>
					<a href="supported-devices.php#stores" class="btn btn-default" role="button"><span class="glyphicon glyphicon-shopping-cart"></span> Stores</a>
					<a href="screenshots.php" class="btn btn-default" role="button"><span class="glyphicon glyphicon-picture"></span> Screenshots</a>
				</div>
			</div>
			<div class="col-md-3">
				<div class="list-group" style="margin-top: 30px;">
					<span class="list-group-item active"><span class="glyphicon glyphicon-bookmark"></span> Links</span>
					<a href="//redmine.replicant.us/projects/replicant/wiki#Contact" class="list-group-item">Contact</a>
					<a href="https://crm.fsf.org/civicrm/contribute/transact?reset=1&id=19" class="list-group-item">Donate</a>
					<span class="list-group-item active"><span class="glyphicon glyphicon-star"></span> Quick access</span>
					<a href="//redmine.replicant.us/projects/replicant/wiki/ReplicantStatus" class="list-group-item">Replicant status</a>
					<a href="//redmine.replicant.us/projects/replicant/wiki#Replicant-installation" class="list-group-item">Replicant installation</a>
					<a href="//redmine.replicant.us/projects/replicant/wiki#Replicant-build" class="list-group-item">Replicant build</a>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="container" role="main">
	<div class="page-header"><h2>Freedom and privacy/security issues</h2></div>
	<div class="row">
		 <div class="col-md-9">
			<p>Mobile devices such as phones and tablets are taking and increasingly important part in our computing, hence they are particularly subject to freedom and security concerns. These devices are actually full computers with powerful hardware, running complete operating systems that allow for updates, software changes and installable applications: this makes it easy to run <a href="//www.gnu.org/philosophy/free-sw.html">free software</a> on them. Mobile devices are often used for communications and provide hardware features that are sensitive when it comes to privacy and security: GPS, camera, microphone, etc, in addition to storing the user's data. Hence, they are particularly subject to being used to spy on the user.</p>
			<h3>A simplified overview of mobile devices</h3>
			<p><a href="images/freedom-privacy-security-issues/hardware.png" data-lightbox="overview" data-title="Hardware-side overview"><img src="images/freedom-privacy-security-issues/hardware.png" alt="Hardware-side overview" style="width: 250px; float: left;"/></a>On the hardware side, mobile devices are built with a system on a chip (SoC) that includes a processor (CPU) and various other fundamental components, around which are found various integrated circuits, memory (RAM), storage, user input/output (I/O), etc. When the device is telephony-enabled, it also features a modem, which is the component in charge of dealing with the mobile telephony network. Nowadays, it is usually a powerful processor, sometimes with its own memory and storage.</p>
			<p>Regarding the software side of things on mobile devices, the main CPU (inside the SoC) starts by executing initial boot code, often known as the bootrom. This code will look up various places such as NAND, eMMC or MMC (sd/micro sd card) storage, depending on the hardware configuration, to load a bootloader. The bootloader, which is in fact often split in different stages, is in charge of bringing up and configuring various aspects of the hardware and eventually starting the operating system by loading and running its kernel.<br /><a href="images/freedom-privacy-security-issues/software.png" data-lightbox="overview" data-title="Software-side overview"><img src="images/freedom-privacy-security-issues/software.png" alt="Software-side overview" style="width: 250px; float: right;"/></a>The kernel itself, among other things, deals with the hardware directly and provides ways for other programs (running in user-space) to access it. In user-space, hardware abstraction layers are programs specific to each device that know how to properly drive the hardware. They use the kernel to communicate back and forth with the hardware and implement the proper protocols for it.<br /><br />The actual knowledge of how to drive the hardware is split between the kernel and the hardware abstraction layer libraries: both are needed to make it work properly. Hardware abstraction layers provide a generic interface for the framework to use. The framework itself provides an interface for applications that is independent of the device and the hardware. That way, applications can access hardware features through the generic framework interface, which will call the hardware abstraction layer libraries, ending up with the kernel communicating with the hardware.</p>
			<p>Many other components of a mobile device also run software in different forms. The various integrated circuits run small pieces of dedicated software that are called firmwares. When the device is telephony-enabled, there is also software running on the modem. Modern modems are complex and run full operating systems.</p>
			<h3>The current situation of freedom and privacy/security on mobile devices</h3>
			<p>A mobile device respecting the users' freedom would have:<ul><li>Free hardware</li><li>Free firmwares</li><li>Free modem system</li><li>Free bootrom and bootloader</li><li>Free system and applications</li></ul>Regarding <a href="#free-hardware">free hardware</a>, it doesn't quite exist as of today, or barely. Modifying hardware is nearly impossible: new versions of the hardware have to be produced, and those are expensive. While producing printed circuit boards (PCBs) costs a lot of money, producing integrated circuits is out of reach. A few devices come with schematics for the PCB, but that's usually as far as it gets. Hence, totally-free hardware doesn't exist yet.</p>
			<p>Firmwares running inside integrated circuits are most of the time proprietary. While free firmwares are hard to write, some exist for very specific hardware (e.g. <a href="//www.arduino.cc/">Arduino</a>, <a href="//dangerousprototypes.com/docs/Bus_Pirate">Bus Pirate</a>) and sometimes,  manufacturers can liberate firmwares running in their integrated circuits (e.g. <a href="//github.com/qca/open-ath9k-htc-firmware">ath9k_htc</a>). However, it is not always possible to even replace those firmwares: some are loaded to the integrated circuit by the main CPU but some others are pre-installed in the circuit (in that case, they almost seem to behave like hardware) and cannot be updated to a free replacement.</p>
			<p><a href="images/freedom-privacy-security-issues/bad-modem-isolation.png" data-lightbox="current-situation" data-title="Bad modem isolation"><img src="images/freedom-privacy-security-issues/bad-modem-isolation.png" alt="Bad modem isolation" style="width: 250px; float: left;"/></a>The modem system on telephony-enabled mobile devices is always proprietary. While <a href="//bb.osmocom.org/">OsmocomBB</a>, a free software GSM stack exists, it only runs on old feature phones, currently requires a host computer to operate and is not certified to run on public networks. Despite this situation, the modem remains a crucial part for privacy/security: it is nearly always connected to the GSM network, allowing for <a href="//www.gnu.org/philosophy/malware-mobiles.html">remote control</a>. The modem can be more or less damaging to privacy/security depending on what hardware it has access to and can control. That is to say, how isolated it is from the rest of the device.<br /><br />A device with bad modem isolation would allow the modem to access and control key parts of the hardware, such as the RAM, storage, GPS, camera, user I/O and microphone. This situation is terrible for privacy/security as it provides plenty of ways to efficiently spy on the user, triggered remotely over the mobile telephony network. Those are accessible to the mobile telephony operator, but also to attackers setting up fake base stations for that purpose. <a href="images/freedom-privacy-security-issues/good-modem-isolation.png" data-lightbox="current-situation" data-title="Good modem isolation"><img src="images/freedom-privacy-security-issues/good-modem-isolation.png" alt="Good modem isolation" style="width: 250px; float: right;"/></a>On the other hand, when the modem is well-isolated from the rest of the device, it is limited to communicating directly with the SoC and can only access the device's microphone when allowed by the SoC. It is then strictly limited to accessing what it really needs, which considerably reduces its opportunities to spy on the user. While it doesn't solve any of the freedom issues, having an isolated modem is a big step forward for privacy/security. However, it is nearly impossible to be entirely sure that the modem is actually isolated, as any documentation about the device cannot be trusted, due to the lack of effective hardware freedom. On the other hand, it is possible to know that the modem is not isolated, when there is proof that it can access hardware that could be used to spy on the user.</p>
			<p>Looking at the software that runs early on the SoC, the first component is the bootrom. It is always proprietary and is stored in read-only memory, so it cannot be changed (in that case, it almost seems to behave like hardware). However, regarding the bootloader, the situation is different for each platform. There are actually multiple stages of bootloaders, some of which can be free. However, it also occurs that the bootloaders are cryptographically signed with a private key. In that case, the bootrom will check the signature against a public key that cannot be replaced and only run the bootloader if the signature matches. That sort of tivoization prevents replacing pre-installed bootloaders, even when their sources are released as free software. There are some good platforms that don't perform such signature checks and can run free bootloaders (e.g. Allwinner Ax, TI OMAP General-Purpose).</p>
			<p><a href="images/freedom-privacy-security-issues/operating-system.png" data-lightbox="current-situation" data-title="Mobile operating system"><img src="images/freedom-privacy-security-issues/operating-system.png" alt="Mobile operating system" style="width: 250px; float: left;"/></a>The biggest part of the software running on a mobile device is the operating system, that runs on the main CPU. It has access to most integrated circuits (I/O, camera, microphone, GPS, etc) as well as the user's data and communications. It is the most critical part for privacy/security and is also very important for free software as it interacts with the user directly and holds knowledge about communication with the hardware. Many mobile operating systems are mostly free software (e.g. <a href="//www.android.com/">Android</a>, <a href="//mozilla.org/firefox/os">Firefox OS</a>, <a href="//ubuntu.com/phone">Ubuntu Touch</a>, <a href="//www.tizen.org/">Tizen</a>), as they use the <a href="//www.kernel.org/">Linux kernel</a>, a free framework and ship with free base applications. However, the user-space hardware abstraction layers are for the most part proprietary (it varies from one device to another) and they also ship with proprietary loaded firmwares for various integrated circuits. Every piece of proprietary software running on the system is a risk for privacy/security as they can offer <a href="//www.gnu.org/philosophy/malware-mobiles.html">remote access back-doors</a> and compromise the rest of the system.<br />None of these mostly-free systems have a clear policy to reject proprietary software and not advocate its use, except for Replicant.</p>
			<p>While the operating system is a very important piece of software, it doesn't ship with applications that cover the wide spectrum of activities that a mobile device is expected to provide. Thankfully, plenty of free software applications exist for each kind of (mostly-)free operating system, sometimes gathered in free software application stores (such as <a href="//www.f-droid.org/">F-Droid</a> for Android systems).</p>
			<h3>Mobile telephony operators and privacy</h3>
			<p>Even though telephony-enabled mobile devices hold a tremendous potential for spying on the user, they are not the only tools that can be used to spy in the mobile world. Most mobile telephony operators keep track of every message and call made by the user but also gather the real time position of users, filter their mobile data networks and provide security agencies unlimited access to that data, to an extent that depends on the operator, the country and the government.</p>
			<p>As these issues are fundamentally political and not technical (even though technical workarounds are possible in some cases), the proper way to solve those is to demand progress and take political action. It is especially important as the tendency for governments is to worsen the situation by allowing more and more tracking and spying on the users.</p>
		</div>
	</div>
	<div class="page-header" id="recommendations"><h2>Recommendations</h2></div>
	<div class="row">
		 <div class="col-md-9">
			<p>Given the current situation, there is no ideal device available that would satisfy all the requirements to fully respect users' freedom: hardware freedom is missing and most firmwares, modem operating systems and bootroms are non-free. However, it is possible to choose a device that runs with free bootloaders and a free mobile operating system: Replicant, as well as free applications.</p>
			<p>Privacy/security cannot be reliably achieved, but it is possible to get close to it by choosing a device that is not proven to have bad modem isolation, provides a reliable way of deactivating the modem or doesn't feature any modem at all, in addition to running software that is as free as possible and following some general good advice.</p>
			<div class="alert alert-danger" role="alert">If compromising on privacy/security is not an option, or anything serious is at stake (e.g. political activism or journalism in a sensitive area), it is advised to avoid using a telephony-enabled device at all.</div>
			<h3>Choosing the best Replicant-supported device</h3>
			<p>Each device comes with its own share of freedom and privacy/security-related problems, that are detailed on the devices' <a href="//redmine.replicant.us/projects/replicant/wiki">wiki</a> pages. Among the devices that Replicant supports, some perform better than others when it comes to free software support and modem isolation.</p>
			<p>Replicant-supported phones recommendations:<ul><li>The <a href="//redmine.replicant.us/projects/replicant/wiki/GTA04">GTA04</a> should be the preferred choice as it can run Replicant with free bootloaders and was not proven to have bad modem isolation: instead, the documentation about the hardware indicates very strong modem isolation. The GTA04 is not fully supported by Replicant yet but we are currently working to improve the situation.</li><li>Second choices include the <a href="//redmine.replicant.us/projects/replicant/wiki/GalaxyS2I9100">Galaxy S 2 (I9100)</a>, the <a href="//redmine.replicant.us/projects/replicant/wiki/GalaxyS3I9300">Galaxy S 3 (I9300)</a>, the <a href="//redmine.replicant.us/projects/replicant/wiki/GalaxyNote2N7100">Galaxy Note 2 (N7100)</a> and the <a href="//redmine.replicant.us/projects/replicant/wiki/GalaxyNexusI9250">Galaxy Nexus (I9250)</a>, in order of supported hardware features in Replicant (more to less). These devices are fairly common and easy to find. They do not run free bootloaders, but were not proven to have bad modem isolation and perform well with Replicant.</li></ul></p>
			<p>Replicant-supported tablets recommendations:<ul><!-- <li>Any of the supported Sunxi tablets should be the preferred choice as they can run Replicant with free bootloaders and usually do not come with a modem. The few models that do were not proven to have bad modem isolation.</li><li>The <a href="http://redmine.replicant.us/projects/replicant/wiki/GalaxyTab270P31xx">Galaxy Tab 2 7.0 (P31x0)</a> would be a second choice for a tablet. It is fairly common and easy to find. However, it does not run a free bootloader. It exists in a Wi-Fi-only version and the version featuring a modem was not proven to have bad modem isolation.</li> --><li>The <a href="http://redmine.replicant.us/projects/replicant/wiki/GalaxyTab270P31xx">Galaxy Tab 2 7.0 (P31x0)</a> is the preferred choice for a tablet. It is fairly common and easy to find. However, it does not run a free bootloader. It exists in a Wi-Fi-only version and the version featuring a modem was not proven to have bad modem isolation.</li></ul></p>
			<h3>General good advice for freedom and privacy/security</h3>
			<p>Some general good advice to ensure the best possible respect of freedom and privacy/security on mobile devices includes:<ul><li>Installing only free software applications, from trusted sources such as F-Droid on Replicant.</li><li>Encrypting the device's storage, to prevent some unauthorized access to the device's data.</li><li>Using software that provides secure peer-to-peer-encrypted communications such as <a href="//dev.guardianproject.info/projects/gibberbot">ChatSecure</a> for instant messaging and <a href="//thialfihar.org/projects/apg/">AGP</a> with <a href="//code.google.com/p/k9mail">K-9 Mail</a> for emails on Replicant.</li><li>Using <a href="//www.torproject.org/">Tor</a> to achieve reliable anonymity, for instance with <a href="//www.torproject.org/docs/android.html.en">Orbot</a> on Replicant.</li><li>If the device is telephony-enabled, switching the modem to airplane mode or (when possible) turning it off when not in use, to avoid being tracked at all times.</li><li>Browsers using the webview framework (such as the browser shipped with Replicant and <a href="https://github.com/anthonycr/Lightning-Browser">Lightning</a>) are subject to <a href="https://community.rapid7.com/community/metasploit/blog/2015/01/11/google-no-longer-provides-patches-for-webview-jelly-bean-and-prior">various security flaws</a> in Replicant 4.2.</li></ul>In addition, the <a href="//www.fsf.org/">Free Software Foundation</a> provides a <a href="//www.fsf.org/campaigns/surveillance">comprehensive guide to help protect freedom and privacy</a> and the Tor project an article entitled <a href="//blog.torproject.org/blog/mission-impossible-hardening-android-security-and-privacy">Mission Impossible: Hardening Android for Security and Privacy</a>.</p>
		</div>
	</div>
	<div class="page-header"><h2><small>Notes</small></h2></div>
	<div class="row">
		 <div class="col-md-9">
			<p id="free-hardware">Free hardware refers to hardware that allows the same four essential freedoms that free software describes, transposed to hardware. Roughly, it means that the users have the freedom to use, duplicate, distribute, study, change and improve the hardware and its design. The equivalent of source code for hardware would be the hardware design source, in the form of schematics, implementation designs or hardware description language sources that could be used to produce the hardware from scratch. It is the preferred source for hardware designers to describe the hardware.</p>
			<p>Such a transposition of the four essential freedoms of free software to hardware could be:<ul><li>The freedom to use the hardware, for any purpose.</li><li>The freedom to study how the hardware works, and change it so it works as you wish. Access to the hardware design source is a precondition for this.</li><li>The freedom to redistribute copies of the hardware and its design so you can help your neighbor.</li><li>The freedom to distribute copies of your modified versions to others. By doing this you can give the whole community a chance to benefit from your changes. Access to the hardware design source is a precondition for this. </li></ul></p>
		</div>
	</div>
</div>

<hr />

<footer class="container text-center">
	<p>Unless specified otherwise, the content on this website is available under the terms of the <a href="//creativecommons.org/licenses/by-sa/3.0/">Creative Commons BY-SA 3.0 license</a>.</p>
	<p>Proudly powered by free software: <a href="//php.net/">PHP</a>, <a href="//getbootstrap.com/">Bootstrap</a>, <a href="//simplepie.org/">SimplePie</a>, <a href="//lokeshdhakar.com/projects/lightbox2/">Lightbox</a></p>
	<p><a href="javascript.php" rel="jslicense">JavaScript license information</a></p>
</footer>


<script src="js/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/lightbox.min.js"></script>

</body>

</html>
