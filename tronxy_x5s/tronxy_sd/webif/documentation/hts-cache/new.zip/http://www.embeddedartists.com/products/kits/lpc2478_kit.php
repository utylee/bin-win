<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"
  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" version="XHTML+RDFa 1.0" dir="ltr">

<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="http://www.embeddedartists.com/sites/default/files/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="shortlink" href="/node/119" />
<link rel="canonical" href="/products/kits/lpc2478_kit.php" />
<meta name="Generator" content="Drupal 7 (http://drupal.org)" />
  <title>LPC2478-32 Developer&#039;s Kit | Embedded Artists AB</title>
  <link type="text/css" rel="stylesheet" href="http://www.embeddedartists.com/sites/default/files/css/css_xE-rWrJf-fncB6ztZfd2huxqgxu4WO-qwma6Xer30m4.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.embeddedartists.com/sites/default/files/css/css_zZHlEodnSygSi7Z3MiAEN00-r_e0lU280SX_N-u7ACM.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.embeddedartists.com/sites/default/files/css/css_MEnisfIcJfQRKNk4waHZ71I4qOMe3UafgsDpz6hhQOI.css" media="all" />
  <script type="text/javascript" src="http://www.embeddedartists.com/sites/default/files/js/js_UWQINlriydSoeSiGQxToOUdv493zEa7dpsXC1OtYlZU.js"></script>
<script type="text/javascript" src="http://www.embeddedartists.com/sites/default/files/js/js_I8yX6RYPZb7AtMcDUA3QKDZqVkvEn35ED11_1i7vVpc.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
(function(i,s,o,g,r,a,m){i["GoogleAnalyticsObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","//www.google-analytics.com/analytics.js","ga");ga("create", "UA-350486-1", {"cookieDomain":"auto"});ga("send", "pageview");
//--><!]]>
</script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"ea1","theme_token":"yORd4qLmPl8NKlNqDJmsQs70ikhkfr2wdkOf_owpmqA","js":{"misc\/jquery.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"sites\/all\/modules\/google_analytics\/googleanalytics.js":1,"0":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"modules\/field\/theme\/field.css":1,"modules\/node\/node.css":1,"modules\/search\/search.css":1,"modules\/user\/user.css":1,"sites\/all\/modules\/ckeditor\/css\/ckeditor.css":1,"sites\/all\/themes\/ea1\/css\/styles.css":1,"sites\/all\/themes\/ea1\/css\/jquery.ui.accordion.css":1,"sites\/all\/themes\/ea1\/css\/jquery.ui.theme.css":1}},"googleanalytics":{"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip"},"urlIsAjaxTrusted":{"\/products\/kits\/lpc2478_kit.php":true}});
//--><!]]>
</script>
</head>
<body class="html not-front not-logged-in no-sidebars page-node page-node- page-node-119 node-type-ea-product" >
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable">Skip to main content</a>
  </div>
    <div id="page-wrapper"><div id="page">

  <div id="fineLine"></div>

  <div id="workArea">
  
    <div id="header" class="with-secondary-menu">

      <a id="logo" href="/">
      <!--<div id="logo"></div>--><!-- close logo -->
      </a>
      
      <div id="strapLine"></div><!-- close strapLine -->

			<div id="topMenu">

			    			      <div id="secondary-menu" class="navigation">
			        <h2 class="element-invisible">Secondary menu</h2><ul id="secondary-menu-links" class="links inline"><li class="menu-222 first"><a href="/" title="">Home</a></li>
<li class="menu-238"><a href="/about">About Us</a></li>
<li class="menu-239"><a href="/careers">Careers</a></li>
<li class="menu-223"><a href="/contact">Contact Us</a></li>
<li class="menu-265 last"><a href="/login">Log in</a></li>
</ul>			      </div> <!-- /#secondary-menu -->
			    				
			</div><!-- close topMenu -->
      
       <div id="block-eashop-ea-shopping-basket" class="block block-eashop">

    <h2 class="element-invisible">Shopping basket</h2>
  
  <div class="content">
    <div id="basket"><a href="/cart" rel="nofollow"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/trolley.png" alt="View Cart" /></a><a href="/cart" rel="nofollow">Shopping Cart</a><span>Items</span> 0<span>Cost</span> &euro;0</div> <!-- close basket -->  </div>
</div>
      


      

      

    </div> <!--  /#header -->
    
		<div id="redMenu">
			<div id="bevelEffect"></div><!-- bevelEffect -->
			        
        		      <div id="main-menu" class="navigation">       
            <h2 class="element-invisible">Main menu</h2><ul class="mlevel-0"><li class="active"><a href="/products">Products</a><ul class="mlevel-1"><li class="active"><a href="/products/kits">Developer&#039;s Kits</a><ul class="mlevel-2"><li class=""><a href="/products/kits/imx6solox_kit.php">iMX6 SoloX Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/imx6quad_kit.php">iMX6 Quad Developer&#039;s Kit</a></li><li class=""><a href="/products/kit/imx6duallite_kit.php">iMX6 DualLite Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/imx6ultralite_kit.php">iMX6 UltraLite Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/imx7dual_ucom_kit.php">iMX7 Dual uCOM Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc1788_kit.php">LPC1788 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc2468_kit.php">LPC2468 Developer&#039;s Kit</a></li><li class="active"><a href="/products/kits/lpc2478_kit.php" class="active">LPC2478-32 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc2478_16_kit.php">LPC2478-16 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3141_kit.php">LPC3141 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3152_kit.php">LPC3152 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3250_kit.php">LPC3250 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3250_kit_v2.php">LPC3250 Developer&#039;s Kit v2</a></li><li class=""><a href="/products/kits/lpc4088_kit.php">LPC4088 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc4357_kit.php">LPC4357 Developer&#039;s Kit</a></li></ul></li><li class=""><a href="/products/oem">COM/OEM Boards</a><ul class="mlevel-2"><li class=""><a href="/products/com/imx6solox.php">iMX6 SoloX COM Board</a></li><li class=""><a href="/products/com/imx6quad.php">iMX6 Quad COM Board</a></li><li class=""><a href="/products/com/imx6duallite.php">iMX6 DualLite COM Board</a></li><li class=""><a href="/products/com/imx6ultralite.php">iMX6 UltraLite COM Board</a></li><li class=""><a href="/products/com/imx7dual_ucom.php">iMX7 Dual uCOM Board</a></li><li class=""><a href="/products/oem/lpc1788_oem.php">LPC1788 OEM Board</a></li><li class=""><a href="/products/oem/lpc2468_16_oem.php">LPC2468-16 OEM Board</a></li><li class=""><a href="/products/oem/lpc2478_oem.php">LPC2478-32 OEM Board</a></li><li class=""><a href="/products/oem/lpc2478_oem_16.php">LPC2478-16 OEM Board</a></li><li class=""><a href="/products/oem/lpc3141_oem.php">LPC3141 OEM Board</a></li><li class=""><a href="/products/oem/lpc3152_oem.php">LPC3152 OEM Board</a></li><li class=""><a href="/products/oem/lpc3250_oem.php">LPC3250 OEM Board</a></li><li class=""><a href="/products/oem/lpc4088_oem.php">LPC4088 OEM Board</a></li><li class=""><a href="/products/oem/lpc4357_oem.php">LPC4357 OEM Board</a></li><li class=""><a href="/products/com/imx6_carrier_board.php">COM Carrier Board</a></li></ul></li><li class=""><a href="/products/displaymodules">Display Modules</a><ul class="mlevel-2"><li class=""><a href="/products/displaymodules/43rtp.php">LPC4088 Display Module - 4.3&quot; Resistive TP</a></li><li class=""><a href="/products/displaymodules/43ctp.php">LPC4088 Display Module - 4.3&quot; Capacitive TP</a></li><li class=""><a href="/products/displaymodules/50rtp.php">LPC4088 Display Module - 5&quot; Resistive TP</a></li></ul></li><li class=""><a href="/products/lpcxpresso">LPCXpresso &amp; mbed</a><ul class="mlevel-2"><li class=""><a href="/products/lpcxpresso/lpclink2.php">LPC-Link 2</a></li><li class=""><a href="/products/lpcxpresso/lpc812_max.php">LPC812 MAX Board</a></li><li class=""><a href="/products/lpcxpresso/experiment_max_kit.php">LPC812 MAX Experiment Kit</a></li><li class=""><a href="/products/lpcxpresso/experiment_kit.php">LPCXpresso Experiment Kit</a></li><li class=""><a href="/products/lpcxpresso/lpc1115_xpr.php">LPC1115 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11C24_xpr.php">LPC11C24 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11U24_xpr.php">LPC11U24 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11U37H_xpr.php">LPC11U37H LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11U68_xpr.php">LPC11U68 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1227_xpr.php">LPC1227 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1347_xpr.php">LPC1347 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1549_xpr.php">LPC1549 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1769_cmsis_xpr.php">LPC1769 LPCXpresso/CD</a></li><li class=""><a href="/products/lpcxpresso/lpc1769_xpr.php">LPC1769 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/xpr_prototype.php">LPCXpresso Prototype Board</a></li><li class=""><a href="/products/lpcxpresso/xpr_base.php">LPCXpresso Base Board</a></li><li class=""><a href="/products/lpcxpresso/xpr_value.php">LPCXpresso Value Pack</a></li><li class=""><a href="/products/lpcxpresso/lpc54102_xpr.php">LPC54102 LPCXpresso</a></li><li class=""><a href="/products/lpcxpresso/lpc824_xpr.php">LPC824 LPCXpresso Board</a></li></ul></li><li class=""><a href="/products/boards">QuickStart Boards</a><ul class="mlevel-2"><li class=""><a href="/products/boards/lpc4088_qsb.php">LPC4088 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc4088_exp_bb.php">LPC4088 Experiment Base Board</a></li><li class=""><a href="/products/boards/lpc4088_qsb_bb.php">LPC4088 QSB Base Board</a></li><li class=""><a href="/products/boards/lpc11d14_qsb.php">LPC11D14 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc12d27_qsb.php">LPC12D27 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc11u35_qsb.php">LPC11U35 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc1343_qsb.php">LPC1343 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc2106_rs232.php">LPC2106 RS232 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc2129_can.php">LPC2129 CAN QuickStart Board</a></li><li class=""><a href="/products/boards/lpc2148.php">LPC2148 USB QuickStart Board</a></li><li class=""><a href="/products/boards/prototype.php">QuickStart Prototype Board</a></li></ul></li><li class=""><a href="/products/app">Application Kits</a><ul class="mlevel-2"><li class=""><a href="/products/app/labtool.php">LabTool</a></li><li class=""><a href="/products/app/aoa_kit.php">Android Open Accessory Application (AOAA) Kit</a></li><li class=""><a href="/products/app/lowpower_oryx">Low-power Application Kit (Oryx)</a></li></ul></li><li class=""><a href="/products/education">Education Boards</a><ul class="mlevel-2"><li class=""><a href="/products/boards/lpc4088_exp_bb_bundle.php">LPC4088 Experiment Bundle</a></li></ul></li><li class=""><a href="/products/displays">Displays</a><ul class="mlevel-2"><li class=""><a href="/products/displays/15_rgb_oled.php">1.5 inch RGB OLED 128x128 px</a></li><li class=""><a href="/products/displays/lcd_135_memory.php">1.35 inch Memory LCD 96x96 px</a></li><li class=""><a href="/products/displays/lcd_27_epaper.php">2.7 inch E-paper Display</a></li><li class=""><a href="/products/displays/lcd_qvga_32.php">3.2 inch QVGA LCD Color Display</a></li><li class=""><a href="/products/displays/lcdb_43.php">LCD Board, 4.3 inch TFT</a></li><li class=""><a href="/products/displays/lcdb_70.php">LCD Board, 7 inch TFT</a></li><li class=""><a href="/products/displays/qvga_adapter.php">QVGA Display Adapter</a></li><li class=""><a href="/products/displays/qvga_adapter_kit.php">QVGA Display Adapter Kit</a></li><li class=""><a href="/products/displays/display_expansion.php">Display Expansion Board</a></li><li class=""><a href="/products/displays/com_disp_adapter.php">COM Display Adapter</a></li><li class=""><a href="/products/displays/disp_exp_43.php">Display Expansion Kit, 4.3 inch</a></li><li class=""><a href="/products/displays/disp_exp_50.php">Display Expansion Kit, 5 inch</a></li></ul></li><li class=""><a href="/products/tools">Tools</a><ul class="mlevel-2"><li class=""><a href="/products/tools/tool_ulink2.php">Keil ULINK2</a></li><li class=""><a href="/products/tools/tool_arm_mdk.php">Keil RealView MDK</a></li><li class=""><a href="/products/tools/tool_cr_redprobe.php">Code Red&#039;s Red Probe+</a></li></ul></li><li class=""><a href="/products/acc">Accessories</a><ul class="mlevel-2"><li class=""><a href="/products/acc/acc_jtag_adapter_kit.php">10-pin to 20-pin JTAG Adapter</a></li><li class=""><a href="/products/acc/acc_rf_adapter.php">RF Adapter Board</a></li><li class=""><a href="/products/acc/acc_1x27_lists.php">1x27 Pinlists and Headers</a></li><li class=""><a href="/products/acc/acc_14pos_adapter.php">14-pos Adapter 50 mil to 100 mil</a></li><li class=""><a href="/products/acc/acc_gps.php">GPS Receiver Board</a></li><li class=""><a href="/products/acc/cell_2g_shield.php">Cellular Shield 2.5G/GSM</a></li><li class=""><a href="/products/acc/cell_pos_shield.php">Cellular and Positioning Shield 2.5G</a></li><li class=""><a href="/products/acc/cell_3g_pos_shield.php">Cellular and Positioning Shield 3G/UMTS</a></li></ul></li><li class=""><a href="/products/cables">Cables</a><ul class="mlevel-2"><li class=""><a href="/products/acc/acc_usb_a_minib.php">USB Cable A to mini-B</a></li><li class=""><a href="/products/acc/acc_usb_a_b.png">USB Cable A to B</a></li><li class=""><a href="/products/acc/acc_idc_10.php">10-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_14_50mil.php">14-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_14_100mil.php">14-pos IDC Ribbon Cable 100 mil</a></li><li class=""><a href="/products/acc/acc_idc_20.php">20-pos IDC Ribbon Cable</a></li><li class=""><a href="/products/acc/acc_idc_20_50mil.php">20-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_24_50mil.php">24-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_50.php">50-pos IDC Ribbon Cable</a></li><li class=""><a href="/products/acc/acc_idc_64.php">64-pos IDC Ribbon Cable</a></li><li class=""><a href="/products/acc/acc_wire_mm.php">Jumper Wires M/M 50 Pack</a></li><li class=""><a href="/products/acc/acc_wire_fm.php">Jumper Wires F/M 50 Pack</a></li><li class=""><a href="/products/acc/acc_wire_ff.php">Jumper Wires F/F 50 Pack</a></li><li class=""><a href="/products/acc/acc_fpc_61.php">61-pos FPC cable 0.3 mm pitch</a></li><li class=""><a href="/products/acc/acc_26_pos_cable.php">26-pos Cable for LabTool</a></li></ul></li><li class=""><a href="/highres_photos.php">High Resolution Photos</a></li></ul></li><li class=""><a href="/support">Support</a><ul class="mlevel-1"><li class=""><a href="/support/overview">Product Support</a></li><li class=""><a href="/support/faq.php">FAQ</a></li><li class=""><a href="/support/problem_report">Problem Report</a></li></ul></li><li class=""><a href="/shop">How to buy</a><ul class="mlevel-1"><li class=""><a href="/shop/distributors.php">Distributors</a></li><li class=""><a href="/shop/shop_info.php">Shipping and Handling</a></li></ul></li><li class=""><a href="/about">About Us</a><ul class="mlevel-1"><li class=""><a href="/news">News</a></li><li class=""><a href="/sustainability">Sustainability</a><ul class="mlevel-2"><li class=""><a href="/emissions">What have we done to decrease our emissions?</a></li><li class=""><a href="/trees">Tree Planting</a></li></ul></li><li class=""><a href="/product_compliance">Product Compliance</a></li><li class=""><a href="/long_term_availability">Long Term Availability</a></li><li class=""><a href="/careers">Careers</a></li><li class=""><a href="/corporate/partners">Partners</a></li><li class=""><a href="/testimonials">Customer Testimonials</a></li><li class=""><a href="/customerprojects">Customer Projects</a></li></ul></li></ul>		      </div> <!-- /#main-menu -->          
        
        <div id="block-search-form" class="block block-search">

    
  <div class="content">
    <form action="/products/kits/lpc2478_kit.php" method="post" id="search-block-form" accept-charset="UTF-8"><div><div class="container-inline">
      <h2 class="element-invisible">Search form</h2>
    <div class="form-item form-type-textfield form-item-search-block-form">
  <label class="element-invisible" for="edit-search-block-form--2">Search </label>
 <input title="Enter the terms you wish to search for." type="text" id="edit-search-block-form--2" name="search_block_form" value="" size="15" maxlength="128" class="form-text" />
</div>
<div class="form-actions form-wrapper" id="edit-actions"><input type="submit" id="edit-submit" name="op" value="Search" class="form-submit" /></div><input type="hidden" name="form_build_id" value="form-yVwlZgOLS0bZ-ZWVJJqchHJC1I7wRIxeOGUv_Hak4is" />
<input type="hidden" name="form_id" value="search_block_form" />
  
</div>
</div></form>  </div>
</div>
        


      <!-- close searchBox -->
			
		</div><!-- close redMenu -->
      

    
		<div class="content">
    
      
    
      <a id="main-content"></a>
            
            
     
              <div class="tabs">
                  </div>
                          <div class="region region-content">
    <div id="block-system-main" class="block block-system">

    
  <div class="content">
    <div id="node-119" class="node node-ea-product clearfix">

   
  <div class="content clearfix">

    <div id="products">
      <div id="productImage">
        <div class="field field-name-ea-product-banner field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img src="http://www.embeddedartists.com/sites/default/files/image/product/kit_lpc2478_32_banner.png" width="501" height="322" alt="LPC2478 Developer&#039;s Kit" title="LPC2478 Developer&#039;s Kit" /></div></div></div>      </div>
  
    <div class="field field-name-ea-buy-link field-type-buy-now field-label-hidden"><div class="field-items"><div class="field-item even"><div id="productPrices">
        <ul>
      
          <li>
          
            <div class="title">Price</div>        
            <div class="price">249&euro;</div>
          <div class="additional">32-bit databus</div><a href="/cart/add/EA-OEM-203/1"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/buy3.png" alt="Buy Now" /></a>
            <div class="art">Art. EA-OEM-203</div>
                
          </li> 
          
          <li>
          
            <div class="title">Price</div>        
            <div class="price">244&euro;</div>
          <div class="additional">16-bit databus</div><a href="/cart/add/EA-OEM-204/1"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/buy3.png" alt="Buy Now" /></a>
            <div class="art">Art. EA-OEM-204</div>
                
          </li> 
            </ul>
       </div>
      </div></div></div>   
    </div>
    
    <div class="mainContent">
    
      <a href="/highres_photos.php">[High Resolution Photos]</a>
      <div class="contentTitle">
        LPC2478-32 Developer&#039;s Kit      </div><!-- close contentTitle -->      
          
      <div class="field field-name-body field-type-text-with-summary field-label-hidden"><div class="field-items"><div class="field-item even"><p>Embedded Artists' <b>LPC2478 Developer's Kit</b> lets you get up-and-running quickly with the LPC2478 OEM Board. The LPC2478 OEM Board is equipped with NXP's <b>ARM7TDMI-S</b> based LPC2478 microcontroller suitable for a wide range of applications that requires advanced communication and high quality graphic displays.</p>
<p>The Kit is perfect for running <b>uClinux</b> with its large on-board RAM and Flash, network and graphics capabilities.</p>
<p style="padding-right: 20px;">Focus on your value-added application by using this Developer's Kit as your prototyping platform. It includes the software components needed to get <b>up-and-running</b> with your software development on <b>day 1</b>.</p>
<p style="padding-right: 20px;">When you are finished with prototyping and/or evaluation you can <b>easily transfer</b> your application and the OEM Board <b>into production</b>.</p>
</div></div></div>      
    </div>
    
      
      <div id="productSection">  <div id="productSectionTitle"><h1>Specification</h1></div>  <div id="productSectionContent"><h3 class="std_header_3">LPC2478 OEM Board</h3>
<table border="0" cellpadding="5" cellspacing="0"><tbody><tr><td valign="top"><i>Processor</i></td>
<td>NXP's ARM7TDMI LPC2478 microcontroller in BGA package</td>
</tr><tr><td valign="top"><i>Program Flash</i></td>
<td>128 MB NAND FLASH, 4 MB NOR FLASH + 512 kB internal</td>
</tr><tr><td valign="top"><i>Data Memory</i></td>
<td>32 MB SDRAM + 96 KB internal<br /><b>32- or 16-bit data bus to SDRAM</b></td>
</tr><tr><td valign="top"><i>Ethernet</i></td>
<td>100/10M Ethernet interface based on National DP83848 Ethernet PHY</td>
</tr><tr><td valign="top"><i>Clock Crystals</i></td>
<td>• 12.000 MHz crystal for CPU<br />
			• 32.768 kHz crystal for RTC</td>
</tr><tr><td valign="top"><i>Dimensions</i></td>
<td>66 x 48 mm</td>
</tr><tr><td valign="top"><i>Power</i></td>
<td>• +3.3V powering</td>
</tr><tr><td valign="top"><i>Connectors</i></td>
<td>• 200 pos expansion connector (as defined in SODIMM standard), 0.6mm pitch</td>
</tr><tr><td valign="top"><i>Other</i></td>
<td>• 256 Kbit I2C E2PROM for storing non-volatile parameters<br />
			• Buffered 32- or 16-bit databus</td>
</tr></tbody></table><h3 class="std_header_3">QVGA Base Board</h3>
<table border="0" cellpadding="5" cellspacing="0"><tbody><tr><td valign="top"><i>Display</i></td>
<td>• 3.2 inch QVGA TFT color LCD with touch screen panel</td>
</tr><tr><td valign="top"><i>Connectors</i></td>
<td>• 200 pos SODIMM connector for OEM Board<br />
			• Expansion connector with all LCD controller signals, for custom displays<br />
			• Expansion connector with all cpu signals<br />
			• Ethernet connector (RJ45)<br />
			• MMC/SD interface &amp; connector<br />
			• CAN interface &amp; connector<br />
			• JTAG connector<br />
			• Pads for ETM connector</td>
</tr><tr><td valign="top"><i>Interfaces</i></td>
<td>• USB OTG interface &amp; connector<br />
			• USB host interface &amp; connector<br />
			• Full modem RS232 on UART #1 (cannot be used on 32-bit databus cpu boards, but RxD2/TxD2 can alternatively be connected to the RS232 interface)<br />
			• Dual CAN interface &amp; connector<br />
			• IrDA tranceiver interface</td>
</tr><tr><td valign="top"><i>Power</i></td>
<td>• Power supply, either via USB or external 9-15V DC<br />
			• 0.3F capacitor backup for RTC and LED on ALARM output</td>
</tr><tr><td valign="top"><i>Expansion</i></td>
<td>• Expansion connector with all LCD controller signals, for custom displays<br />
			• Expansion connector with all cpu signals</td>
</tr><tr><td valign="top"><i>Other</i></td>
<td>• 5-key joystick<br />
			• 3 axis accelerometer<br />
			• Push-button key and LED on P2.10<br />
			• 4 push-button keys via I2C<br />
			• 8 LEDs (via I2C)<br />
			• 1 Analog inputs<br />
			• USB-to-serial bridge on UART #0, and ISP functionality<br />
			• Reset push-button and LED<br />
			• Speaker output (DAC)<br />
			• 240x150 mm in size</td>
</tr></tbody></table><p>The <strong>LPC2478 Developer's Kit</strong> is an <a href="/long_term_availability#prodclass">Evaluation product</a> not designed for integration or long time availability.<br />
The <strong>LPC2478 OEM Board</strong> is however an <a href="/long_term_availability#prodclass">Integration product</a></p>
<p> </p>
</div></div>      <div id="productSection">  <div id="productSectionTitle"><h1>Documentation and Resources</h1></div>  <div id="productSectionContent"><p>The following resources are available for download either directly below or from our support site after registration of the LPC2478 Developer's Kit.</p>
<h3>Documents</h3>
<ul><li><a href="/support/oem/lpc2478">uClinux Getting Started Book</a> (<em>Login required</em>)</li>
<li><a href="/sites/default/files/support/oem/lpc2478/LPC2478_OEM_Board_Users_Guide.pdf" target="_blank">User's Manual</a></li>
<li><a href="/sites/default/files/docs/datasheet/LPC2478_OEM_Board_Datasheet.pdf" target="_blank">LPC2478 OEM Board Datasheet</a></li>
<li><a href="/sites/default/files/docs/measurements/OEM_Board_measurements.pdf" target="_blank">LPC2478 OEM Board Measurements</a></li>
<li><a href="/sites/default/files/docs/measurements/QVGA_BaseBoard_Measures.pdf" target="_blank">QVGA Base Board Measurements</a></li>
<li><a href="/sites/default/files/docs/OEM_boards_Flyer.pdf" target="_blank">OEM Board Make or Buy Analysis</a></li>
<li><a href="/sites/default/files/support/oem/OEM_Board_Integration_Guide.pdf">OEM Board Integration Guide</a></li>
<li><a href="/support/oem/lpc2478">LPC2478 OEM Board Schematics</a> (<em>Login required</em>)</li>
<li><a href="/support/oem/lpc2478">QVGA Base Board Schematics</a> (<em>Login required</em>)</li>
<li><a href="/support/oem/lpc2478">Links to datasheets for key components</a> (<em>Login required</em>)</li>
<li><a href="/sites/default/files/docs/declarations/CE_DoC_LPC2478_Developers_Kit_2011-12-08.pdf" target="_blank">CE Declaration of Conformity</a></li>
<li><a href="/sites/default/files/docs/declarations/ROHS2_DoC.pdf" target="_blank">Embedded Artists' general RoHS 2 declaration</a></li>
</ul><h3 style="line-height: 20.7999992370605px;">Product Change Note (PCN)</h3>
<ul style="line-height: 20.7999992370605px;"><li><a href="/sites/default/files/support/oem/lpc2478/PCN_EA-OEM-202_Changed_NAND.pdf" target="_blank">NAND change</a> (2015-01-21)</li>
</ul><h3>Software</h3>
<p><a href="/products/sw_disclaimer" target="_blank">Sample Software Disclaimer</a></p>
<ul><li>Several sample applications</li>
<li>uClinux distribution using the 2.6.21 version of the Linux kernel and u-boot v1.1.6 as the bootloader. <strong>Note</strong>: The distribution has been released to the community and is also available at the <a href="http://tech.groups.yahoo.com/group/lpc2400_uClinux/" target="_blank">LPC2400_uClinux Yahoo group.</a></li>
<li>SDRAM initialization code</li>
<li>Pre-emptive Real-time Operating System (RTOS) - devlivered as binary package</li>
<li>QuickStart Build Environment based on GCC</li>
</ul><h2>External Resources</h2>
<ul><li><b>Use CrossWorks</b> - a <a href="http://www.yagarto.de/howto/cwandea/index.html" target="_blank">tutorial</a> about how to use CrossWorks with the LPC2478 OEM Board. The tutorial has been written by Michael Fisher.</li>
</ul></div></div>            <div id="productSection">  <div id="productSectionTitle"><h1>Related Products</h1></div>  <div id="productSectionContent"><div id="productList"><ul><li>  <div class="leftSection"><a href="/products/oem/lpc2478_oem_16.php"><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_product_list/public/image/product/oem_lpc2478_16_front.png?itok=DvAkbOem" alt="LPC2468-16 OEM Board" title="LPC2468-16 OEM Board" /></a>  </div>  <div class="midSection">    <div class="title"><a href="/products/oem/lpc2478_oem_16.php">LPC2478-16 OEM Board</a></div>    <div class="orderNumber">Order number: EA-OEM-201</div>  </div>  <div class="rightSection">  <span class="price">94&euro;  </span><span><a href="/cart/add/EA-OEM-201/1"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/buy3.png" alt="Buy Now" /></a></span>  </div></li><li>  <div class="leftSection"><a href="/products/oem/lpc2478_oem.php"><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_product_list/public/image/product/oem_lpc2478_32_front.png?itok=ufEwPqp5" alt="LPC2478-32 OEM Board" title="LPC2478-32 OEM Board" /></a>  </div>  <div class="midSection">    <div class="title"><a href="/products/oem/lpc2478_oem.php">LPC2478-32 OEM Board</a></div>    <div class="orderNumber">Order number: EA-OEM-202</div>  </div>  <div class="rightSection">  <span class="price">99&euro;  </span><span><a href="/cart/add/EA-OEM-202/1"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/buy3.png" alt="Buy Now" /></a></span>  </div></li><li>  <div class="leftSection"><a href="/products/tools/tool_ulink2.php"><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_product_list/public/image/product/tol_ulink2_0.png?itok=QeT6Ap18" alt="ULINK2 USB-JTAG Adapter" title="ULINK2 USB-JTAG Adapter" /></a>  </div>  <div class="midSection">    <div class="title"><a href="/products/tools/tool_ulink2.php">ULINK2 USB-JTAG Adapter</a></div>    <div class="orderNumber">Order number: EA-TOL-001</div>  </div>  <div class="rightSection">  <span class="price">175&euro;  </span><span><a href="/cart/add/EA-TOL-001/1"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/buy3.png" alt="Buy Now" /></a></span>  </div></li></ul></div></div></div>    
      <div id="productSection">  <div id="productSectionTitle"><h1>FAQ</h1></div>  <div id="productSectionContent"><div id="faqList"><ul class="links"><li class="0 first"><a href="/support/faq.php?id=2">How do I get the schematic?</a></li>
<li class="1"><a href="/support/faq.php?id=5">How can I get help with the Embedded Artists uClinux distribution?</a></li>
<li class="2"><a href="/support/faq.php?id=7">Are your boards RoHS 2 compatible?</a></li>
<li class="3"><a href="/support/faq.php?id=9">What chip revision are your boards using?</a></li>
<li class="4"><a href="/support/faq.php?id=10">Is the design files available (schematic, layout, BOM and Gerber files)?</a></li>
<li class="5"><a href="/support/faq.php?id=11">Keil sells MCB2460 and MCB2470. It looks like your boards. How are they related?</a></li>
<li class="6"><a href="/support/faq.php?id=12">Which boards can run uClinux?</a></li>
<li class="7"><a href="/support/faq.php?id=21">What is the warranty for your boards?</a></li>
<li class="8"><a href="/support/faq.php?id=31">What are the differences between 16-bit and 32-bit LPC2478 OEM Boards? Pros and cons?</a></li>
<li class="9"><a href="/support/faq.php?id=35">What is the maximum clock frequency on LCD-CLKIN (external pixel clock for the LCD controller) on LPC2478/LPC3250?
</a></li>
<li class="10"><a href="/support/faq.php?id=38">Where is the serial number?</a></li>
<li class="11"><a href="/support/faq.php?id=39">Do you have high resolution photos of your products?</a></li>
<li class="12"><a href="/support/faq.php?id=41">Where is the CD/DVD with uClinux distribution?</a></li>
<li class="13"><a href="/support/faq.php?id=42">Is the same base board used in the LPC2478 Developer&#039;s Kit and the LPC3250 Developer&#039;s Kit</a></li>
<li class="14"><a href="/support/faq.php?id=45">Do you have a long-term commitment to production and availability of your boards?</a></li>
<li class="15"><a href="/support/faq.php?id=51">I cannot download the manuals or files in general. What to do?
</a></li>
<li class="16"><a href="/support/faq.php?id=53">Is it possible to migrate to the LPC1788 OEM board from the LPC2478 OEM board? What do I need to consider?</a></li>
<li class="17"><a href="/support/faq.php?id=14">Can I only run uClinux/Linux on the LPC24xx/LPC3xxx boards?</a></li>
<li class="18"><a href="/support/faq.php?id=36">How to erase flash on devices when JTAG/SWD interface accidentally disabled or PLL programmed wrongly by application program that is already in flash?</a></li>
<li class="19"><a href="/support/faq.php?id=37">Which SODIMM connector do you recommend for your OEM boards?</a></li>
<li class="20"><a href="/support/faq.php?id=44">Are all OEM boards based on NXP&#039;s LPC family pin-compatible?</a></li>
<li class="21"><a href="/support/faq.php?id=49">Which free graphical libraries exist for NXP&#039;s processors? </a></li>
<li class="22 last"><a href="/support/faq.php?id=50">What software development environment (IDE, compiler, debugger) is included when buying your boards?</a></li>
</ul></div></div></div>    
    
  </div>



</div>
  </div>
</div>
  </div>
          
    
		</div><!-- close content -->
    
  </div> <!-- /#workArea -->
  
  <div id="footer-wrapper">
    <div id="footer-content">

          <div id="footer-firstcolumn" class="clearfix">
          <div class="region region-footer-firstcolumn">
    <div id="block-block-1" class="block block-block">

    <h2>Useful Information</h2>
  
  <div class="content">
    <ul><li>We are located in Malmö, Sweden.</li>
<li>Embedded Artists AB</li>
<li>Davidshallsgatan 16</li>
<li>211 45 Malmö</li>
</ul><ul><li>Get in touch</li>
<li>Tel +46 (0)40-6110093</li>
<li>Fax +46 (0)40-6110093</li>
<li>Email <a href="/contact">Contact Form</a></li>
</ul><ul><li>Useful Links</li>
<li><a href="/contact">Contact Us</a><a href="contact"> </a></li>
<li><a href="/legal.php">Terms &amp; Conditions</a></li>
<li><a href="/privacy.php">Privacy Policy</a></li>
</ul><ul><li> </li>
<li><a class="feed-icon" href="/rss.xml" target="_blank" title="Subscribe to Embedded Artists RSS Feed"><img alt="Subscribe to Embedded Artists RSS Feed" src="/sites/default/files/image/icons/rss.png" /></a></li>
<li><a href="/newsletter" title="Subscribe to Embedded Artists Newsletter"><img alt="Subscribe to Embedded Artists Newsletter" src="/sites/default/files/image/icons/envelope.png" /></a></li>
<li><a href="https://twitter.com/EmbeddedArtists" title="Follow us on Twitter"><img alt="Follow us on Twitter" src="/sites/default/files/image/icons/twitter.png" /></a></li>
</ul><ul><li> </li>
<li><a href="http://www.youtube.com/user/eavid10?feature=results_main" target="_blank" title="Follow us on YouTube"><img alt="Follow us on YouTube" src="/sites/default/files/image/icons/youtube.png" /></a></li>
<li><a href="http://www.linkedin.com/company/embedded-artists-ab" target="_blank" title="LinkedIn"><img alt="LinkedIn" src="/sites/default/files/image/icons/linkedin.png" /></a></li>
</ul>  </div>
</div>
  </div>
      </div> <!-- /#footer_firstcolumn -->
    
          <div id="footer-secondcolumn" class="clearfix">
          <div class="region region-footer-secondcolumn">
    <div id="block-eashop-ea-partner-view" class="block block-eashop">

    <h2>Partners</h2>
  
  <div class="content">
    <div><a href="/corporate/partners"><ul id="partners"><li><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_partner_view/public/image/partner/nxp_0.png?itok=k8weHDV6" alt="NXP Semiconductors" title="NXP Semiconductors" /></li><li><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_partner_view/public/image/partner/Atollic_logotype_webb_small.png?itok=d7D3JSHK" alt="" title="" /></li></ul></a></div><div><a href="/corporate/partners"><nobr>&raquo;&nbsp;More</nobr></a></div>  </div>
</div>
  </div>
      </div> <!-- /#footer_secondcolumn -->
        


    
    </div>  <!-- /#footer-content --> 
  </div)> <!-- /#footer-wrapper -->
    <br><center>
      <a href="/product_compliance#iso9001">
        <img src="/sites/default/files/image/misc/iso9001_100.jpg" alt="ISO9001" title="ISO9001" style="width: 70px; height: 70px; margin-right: 10px;">
      </a>

      <a href="/product_compliance#iso14001">
        <img src="/sites/default/files/image/misc/iso14001_100.jpg" alt="ISO14001" title="ISO14001" style="width: 70px; height: 70px; margin-right: 10px;">
      </a>      

      <a href="/sustainability">
        <img alt="" src="/sites/default/files/image/EASB_logo_100.png" style="width: 70px; height: 70px; margin-right: 0px;">
      </a>        
<a href="http://www.soliditet.se/lang/en_GB/RatingGuideline" target="_blank" style="text-decoration: none;"><img style="border:0px;" oncontextmenu="return false" title="Our company is credit worthy according to Bisnode's credit assessment system that is based on a number of decision rules. This credit rating is updated on a daily basis&#44; and always shows the current rating and date." alt="Our company is credit worthy according to Bisnode's credit assessment system that is based on a number of decision rules. This credit rating is updated on a daily basis&#44; and always shows the current rating and date." id="img_273_73_px_tr1" src="https://merit.soliditet.se/merit/imageGenerator/display?lang=EN&country=SE&cId=%2BKrj4TgSYbsfq6wXoGmJ2w%3D%3D&cUid=eCpQb6dCrOQ%3D&imgType=img_273_73_px_tr1" /></a>
    </center>  
  
	<br>
  


  

  <!-- <div class="section"> -->
  


  <!--</div>-->
  
</div></div> <!-- /#page, /#page-wrapper -->



  </body>
</html>
