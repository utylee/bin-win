<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"
  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" version="XHTML+RDFa 1.0" dir="ltr">

<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="http://www.embeddedartists.com/sites/default/files/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="shortlink" href="/node/332" />
<link rel="canonical" href="/products/acc/acc_fpc_61.php" />
<meta name="Generator" content="Drupal 7 (http://drupal.org)" />
  <title>61-pos FPC cable 0.3 mm pitch | Embedded Artists AB</title>
  <link type="text/css" rel="stylesheet" href="http://www.embeddedartists.com/sites/default/files/css/css_xE-rWrJf-fncB6ztZfd2huxqgxu4WO-qwma6Xer30m4.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.embeddedartists.com/sites/default/files/css/css_zZHlEodnSygSi7Z3MiAEN00-r_e0lU280SX_N-u7ACM.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.embeddedartists.com/sites/default/files/css/css_MEnisfIcJfQRKNk4waHZ71I4qOMe3UafgsDpz6hhQOI.css" media="all" />
  <script type="text/javascript" src="http://www.embeddedartists.com/sites/default/files/js/js_UWQINlriydSoeSiGQxToOUdv493zEa7dpsXC1OtYlZU.js"></script>
<script type="text/javascript" src="http://www.embeddedartists.com/sites/default/files/js/js_I8yX6RYPZb7AtMcDUA3QKDZqVkvEn35ED11_1i7vVpc.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
(function(i,s,o,g,r,a,m){i["GoogleAnalyticsObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","//www.google-analytics.com/analytics.js","ga");ga("create", "UA-350486-1", {"cookieDomain":"auto"});ga("send", "pageview");
//--><!]]>
</script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"ea1","theme_token":"yORd4qLmPl8NKlNqDJmsQs70ikhkfr2wdkOf_owpmqA","js":{"misc\/jquery.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"sites\/all\/modules\/google_analytics\/googleanalytics.js":1,"0":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"modules\/field\/theme\/field.css":1,"modules\/node\/node.css":1,"modules\/search\/search.css":1,"modules\/user\/user.css":1,"sites\/all\/modules\/ckeditor\/css\/ckeditor.css":1,"sites\/all\/themes\/ea1\/css\/styles.css":1,"sites\/all\/themes\/ea1\/css\/jquery.ui.accordion.css":1,"sites\/all\/themes\/ea1\/css\/jquery.ui.theme.css":1}},"googleanalytics":{"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip"},"urlIsAjaxTrusted":{"\/products\/acc\/acc_fpc_61.php":true}});
//--><!]]>
</script>
</head>
<body class="html not-front not-logged-in no-sidebars page-node page-node- page-node-332 node-type-ea-product" >
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable">Skip to main content</a>
  </div>
    <div id="page-wrapper"><div id="page">

  <div id="fineLine"></div>

  <div id="workArea">
  
    <div id="header" class="with-secondary-menu">

      <a id="logo" href="/">
      <!--<div id="logo"></div>--><!-- close logo -->
      </a>
      
      <div id="strapLine"></div><!-- close strapLine -->

			<div id="topMenu">

			    			      <div id="secondary-menu" class="navigation">
			        <h2 class="element-invisible">Secondary menu</h2><ul id="secondary-menu-links" class="links inline"><li class="menu-222 first"><a href="/" title="">Home</a></li>
<li class="menu-238"><a href="/about">About Us</a></li>
<li class="menu-239"><a href="/careers">Careers</a></li>
<li class="menu-223"><a href="/contact">Contact Us</a></li>
<li class="menu-265 last"><a href="/login">Log in</a></li>
</ul>			      </div> <!-- /#secondary-menu -->
			    				
			</div><!-- close topMenu -->
      
       <div id="block-eashop-ea-shopping-basket" class="block block-eashop">

    <h2 class="element-invisible">Shopping basket</h2>
  
  <div class="content">
    <div id="basket"><a href="/cart" rel="nofollow"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/trolley.png" alt="View Cart" /></a><a href="/cart" rel="nofollow">Shopping Cart</a><span>Items</span> 0<span>Cost</span> &euro;0</div> <!-- close basket -->  </div>
</div>
      


      

      

    </div> <!--  /#header -->
    
		<div id="redMenu">
			<div id="bevelEffect"></div><!-- bevelEffect -->
			        
        		      <div id="main-menu" class="navigation">       
            <h2 class="element-invisible">Main menu</h2><ul class="mlevel-0"><li class="active"><a href="/products">Products</a><ul class="mlevel-1"><li class=""><a href="/products/kits">Developer&#039;s Kits</a><ul class="mlevel-2"><li class=""><a href="/products/kits/imx6solox_kit.php">iMX6 SoloX Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/imx6quad_kit.php">iMX6 Quad Developer&#039;s Kit</a></li><li class=""><a href="/products/kit/imx6duallite_kit.php">iMX6 DualLite Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/imx6ultralite_kit.php">iMX6 UltraLite Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/imx7dual_ucom_kit.php">iMX7 Dual uCOM Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc1788_kit.php">LPC1788 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc2468_kit.php">LPC2468 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc2478_kit.php">LPC2478-32 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc2478_16_kit.php">LPC2478-16 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3141_kit.php">LPC3141 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3152_kit.php">LPC3152 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3250_kit.php">LPC3250 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc3250_kit_v2.php">LPC3250 Developer&#039;s Kit v2</a></li><li class=""><a href="/products/kits/lpc4088_kit.php">LPC4088 Developer&#039;s Kit</a></li><li class=""><a href="/products/kits/lpc4357_kit.php">LPC4357 Developer&#039;s Kit</a></li></ul></li><li class=""><a href="/products/oem">COM/OEM Boards</a><ul class="mlevel-2"><li class=""><a href="/products/com/imx6solox.php">iMX6 SoloX COM Board</a></li><li class=""><a href="/products/com/imx6quad.php">iMX6 Quad COM Board</a></li><li class=""><a href="/products/com/imx6duallite.php">iMX6 DualLite COM Board</a></li><li class=""><a href="/products/com/imx6ultralite.php">iMX6 UltraLite COM Board</a></li><li class=""><a href="/products/com/imx7dual_ucom.php">iMX7 Dual uCOM Board</a></li><li class=""><a href="/products/oem/lpc1788_oem.php">LPC1788 OEM Board</a></li><li class=""><a href="/products/oem/lpc2468_16_oem.php">LPC2468-16 OEM Board</a></li><li class=""><a href="/products/oem/lpc2478_oem.php">LPC2478-32 OEM Board</a></li><li class=""><a href="/products/oem/lpc2478_oem_16.php">LPC2478-16 OEM Board</a></li><li class=""><a href="/products/oem/lpc3141_oem.php">LPC3141 OEM Board</a></li><li class=""><a href="/products/oem/lpc3152_oem.php">LPC3152 OEM Board</a></li><li class=""><a href="/products/oem/lpc3250_oem.php">LPC3250 OEM Board</a></li><li class=""><a href="/products/oem/lpc4088_oem.php">LPC4088 OEM Board</a></li><li class=""><a href="/products/oem/lpc4357_oem.php">LPC4357 OEM Board</a></li><li class=""><a href="/products/com/imx6_carrier_board.php">COM Carrier Board</a></li></ul></li><li class=""><a href="/products/displaymodules">Display Modules</a><ul class="mlevel-2"><li class=""><a href="/products/displaymodules/43rtp.php">LPC4088 Display Module - 4.3&quot; Resistive TP</a></li><li class=""><a href="/products/displaymodules/43ctp.php">LPC4088 Display Module - 4.3&quot; Capacitive TP</a></li><li class=""><a href="/products/displaymodules/50rtp.php">LPC4088 Display Module - 5&quot; Resistive TP</a></li></ul></li><li class=""><a href="/products/lpcxpresso">LPCXpresso &amp; mbed</a><ul class="mlevel-2"><li class=""><a href="/products/lpcxpresso/lpclink2.php">LPC-Link 2</a></li><li class=""><a href="/products/lpcxpresso/lpc812_max.php">LPC812 MAX Board</a></li><li class=""><a href="/products/lpcxpresso/experiment_max_kit.php">LPC812 MAX Experiment Kit</a></li><li class=""><a href="/products/lpcxpresso/experiment_kit.php">LPCXpresso Experiment Kit</a></li><li class=""><a href="/products/lpcxpresso/lpc1115_xpr.php">LPC1115 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11C24_xpr.php">LPC11C24 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11U24_xpr.php">LPC11U24 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11U37H_xpr.php">LPC11U37H LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc11U68_xpr.php">LPC11U68 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1227_xpr.php">LPC1227 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1347_xpr.php">LPC1347 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1549_xpr.php">LPC1549 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/lpc1769_cmsis_xpr.php">LPC1769 LPCXpresso/CD</a></li><li class=""><a href="/products/lpcxpresso/lpc1769_xpr.php">LPC1769 LPCXpresso Board</a></li><li class=""><a href="/products/lpcxpresso/xpr_prototype.php">LPCXpresso Prototype Board</a></li><li class=""><a href="/products/lpcxpresso/xpr_base.php">LPCXpresso Base Board</a></li><li class=""><a href="/products/lpcxpresso/xpr_value.php">LPCXpresso Value Pack</a></li><li class=""><a href="/products/lpcxpresso/lpc54102_xpr.php">LPC54102 LPCXpresso</a></li><li class=""><a href="/products/lpcxpresso/lpc824_xpr.php">LPC824 LPCXpresso Board</a></li></ul></li><li class=""><a href="/products/boards">QuickStart Boards</a><ul class="mlevel-2"><li class=""><a href="/products/boards/lpc4088_qsb.php">LPC4088 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc4088_exp_bb.php">LPC4088 Experiment Base Board</a></li><li class=""><a href="/products/boards/lpc4088_qsb_bb.php">LPC4088 QSB Base Board</a></li><li class=""><a href="/products/boards/lpc11d14_qsb.php">LPC11D14 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc12d27_qsb.php">LPC12D27 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc11u35_qsb.php">LPC11U35 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc1343_qsb.php">LPC1343 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc2106_rs232.php">LPC2106 RS232 QuickStart Board</a></li><li class=""><a href="/products/boards/lpc2129_can.php">LPC2129 CAN QuickStart Board</a></li><li class=""><a href="/products/boards/lpc2148.php">LPC2148 USB QuickStart Board</a></li><li class=""><a href="/products/boards/prototype.php">QuickStart Prototype Board</a></li></ul></li><li class=""><a href="/products/app">Application Kits</a><ul class="mlevel-2"><li class=""><a href="/products/app/labtool.php">LabTool</a></li><li class=""><a href="/products/app/aoa_kit.php">Android Open Accessory Application (AOAA) Kit</a></li><li class=""><a href="/products/app/lowpower_oryx">Low-power Application Kit (Oryx)</a></li></ul></li><li class=""><a href="/products/education">Education Boards</a><ul class="mlevel-2"><li class=""><a href="/products/boards/lpc4088_exp_bb_bundle.php">LPC4088 Experiment Bundle</a></li></ul></li><li class=""><a href="/products/displays">Displays</a><ul class="mlevel-2"><li class=""><a href="/products/displays/15_rgb_oled.php">1.5 inch RGB OLED 128x128 px</a></li><li class=""><a href="/products/displays/lcd_135_memory.php">1.35 inch Memory LCD 96x96 px</a></li><li class=""><a href="/products/displays/lcd_27_epaper.php">2.7 inch E-paper Display</a></li><li class=""><a href="/products/displays/lcd_qvga_32.php">3.2 inch QVGA LCD Color Display</a></li><li class=""><a href="/products/displays/lcdb_43.php">LCD Board, 4.3 inch TFT</a></li><li class=""><a href="/products/displays/lcdb_70.php">LCD Board, 7 inch TFT</a></li><li class=""><a href="/products/displays/qvga_adapter.php">QVGA Display Adapter</a></li><li class=""><a href="/products/displays/qvga_adapter_kit.php">QVGA Display Adapter Kit</a></li><li class=""><a href="/products/displays/display_expansion.php">Display Expansion Board</a></li><li class=""><a href="/products/displays/com_disp_adapter.php">COM Display Adapter</a></li><li class=""><a href="/products/displays/disp_exp_43.php">Display Expansion Kit, 4.3 inch</a></li><li class=""><a href="/products/displays/disp_exp_50.php">Display Expansion Kit, 5 inch</a></li></ul></li><li class=""><a href="/products/tools">Tools</a><ul class="mlevel-2"><li class=""><a href="/products/tools/tool_ulink2.php">Keil ULINK2</a></li><li class=""><a href="/products/tools/tool_arm_mdk.php">Keil RealView MDK</a></li><li class=""><a href="/products/tools/tool_cr_redprobe.php">Code Red&#039;s Red Probe+</a></li></ul></li><li class=""><a href="/products/acc">Accessories</a><ul class="mlevel-2"><li class=""><a href="/products/acc/acc_jtag_adapter_kit.php">10-pin to 20-pin JTAG Adapter</a></li><li class=""><a href="/products/acc/acc_rf_adapter.php">RF Adapter Board</a></li><li class=""><a href="/products/acc/acc_1x27_lists.php">1x27 Pinlists and Headers</a></li><li class=""><a href="/products/acc/acc_14pos_adapter.php">14-pos Adapter 50 mil to 100 mil</a></li><li class=""><a href="/products/acc/acc_gps.php">GPS Receiver Board</a></li><li class=""><a href="/products/acc/cell_2g_shield.php">Cellular Shield 2.5G/GSM</a></li><li class=""><a href="/products/acc/cell_pos_shield.php">Cellular and Positioning Shield 2.5G</a></li><li class=""><a href="/products/acc/cell_3g_pos_shield.php">Cellular and Positioning Shield 3G/UMTS</a></li></ul></li><li class="active"><a href="/products/cables">Cables</a><ul class="mlevel-2"><li class=""><a href="/products/acc/acc_usb_a_minib.php">USB Cable A to mini-B</a></li><li class=""><a href="/products/acc/acc_usb_a_b.png">USB Cable A to B</a></li><li class=""><a href="/products/acc/acc_idc_10.php">10-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_14_50mil.php">14-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_14_100mil.php">14-pos IDC Ribbon Cable 100 mil</a></li><li class=""><a href="/products/acc/acc_idc_20.php">20-pos IDC Ribbon Cable</a></li><li class=""><a href="/products/acc/acc_idc_20_50mil.php">20-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_24_50mil.php">24-pos IDC Ribbon Cable 50 mil</a></li><li class=""><a href="/products/acc/acc_idc_50.php">50-pos IDC Ribbon Cable</a></li><li class=""><a href="/products/acc/acc_idc_64.php">64-pos IDC Ribbon Cable</a></li><li class=""><a href="/products/acc/acc_wire_mm.php">Jumper Wires M/M 50 Pack</a></li><li class=""><a href="/products/acc/acc_wire_fm.php">Jumper Wires F/M 50 Pack</a></li><li class=""><a href="/products/acc/acc_wire_ff.php">Jumper Wires F/F 50 Pack</a></li><li class="active"><a href="/products/acc/acc_fpc_61.php" class="active">61-pos FPC cable 0.3 mm pitch</a></li><li class=""><a href="/products/acc/acc_26_pos_cable.php">26-pos Cable for LabTool</a></li></ul></li><li class=""><a href="/highres_photos.php">High Resolution Photos</a></li></ul></li><li class=""><a href="/support">Support</a><ul class="mlevel-1"><li class=""><a href="/support/overview">Product Support</a></li><li class=""><a href="/support/faq.php">FAQ</a></li><li class=""><a href="/support/problem_report">Problem Report</a></li></ul></li><li class=""><a href="/shop">How to buy</a><ul class="mlevel-1"><li class=""><a href="/shop/distributors.php">Distributors</a></li><li class=""><a href="/shop/shop_info.php">Shipping and Handling</a></li></ul></li><li class=""><a href="/about">About Us</a><ul class="mlevel-1"><li class=""><a href="/news">News</a></li><li class=""><a href="/sustainability">Sustainability</a><ul class="mlevel-2"><li class=""><a href="/emissions">What have we done to decrease our emissions?</a></li><li class=""><a href="/trees">Tree Planting</a></li></ul></li><li class=""><a href="/product_compliance">Product Compliance</a></li><li class=""><a href="/long_term_availability">Long Term Availability</a></li><li class=""><a href="/careers">Careers</a></li><li class=""><a href="/corporate/partners">Partners</a></li><li class=""><a href="/testimonials">Customer Testimonials</a></li><li class=""><a href="/customerprojects">Customer Projects</a></li></ul></li></ul>		      </div> <!-- /#main-menu -->          
        
        <div id="block-search-form" class="block block-search">

    
  <div class="content">
    <form action="/products/acc/acc_fpc_61.php" method="post" id="search-block-form" accept-charset="UTF-8"><div><div class="container-inline">
      <h2 class="element-invisible">Search form</h2>
    <div class="form-item form-type-textfield form-item-search-block-form">
  <label class="element-invisible" for="edit-search-block-form--2">Search </label>
 <input title="Enter the terms you wish to search for." type="text" id="edit-search-block-form--2" name="search_block_form" value="" size="15" maxlength="128" class="form-text" />
</div>
<div class="form-actions form-wrapper" id="edit-actions"><input type="submit" id="edit-submit" name="op" value="Search" class="form-submit" /></div><input type="hidden" name="form_build_id" value="form-0F3r0luLFYtvg_ubJ2XKZdNlCPUC4GVzXZBHn25t8Xo" />
<input type="hidden" name="form_id" value="search_block_form" />
  
</div>
</div></form>  </div>
</div>
        


      <!-- close searchBox -->
			
		</div><!-- close redMenu -->
      

    
		<div class="content">
    
      
    
      <a id="main-content"></a>
            
            
     
              <div class="tabs">
                  </div>
                          <div class="region region-content">
    <div id="block-system-main" class="block block-system">

    
  <div class="content">
    <div id="node-332" class="node node-ea-product clearfix">

   
  <div class="content clearfix">

    <div id="products">
      <div id="productImage">
        <div class="field field-name-ea-product-banner field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img src="http://www.embeddedartists.com/sites/default/files/image/product/acc_fpc_banner.png" width="501" height="322" alt="61-pos FPC cable 0.3 mm pitch" title="61-pos FPC cable 0.3 mm pitch" /></div></div></div>      </div>
  
    <div class="field field-name-ea-buy-link field-type-buy-now field-label-hidden"><div class="field-items"><div class="field-item even"><div id="productPrices">
        <ul>
      
          <li>
          
            <div class="title">Price</div>        
            <div class="price">3.80&euro;</div>
          <a href="/cart/add/EA-ACC-025/1"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/buy3.png" alt="Buy Now" /></a>
            <div class="art">Art. EA-ACC-025</div>
          
            <center>
            <table class="volumePrices" cellspacing="2">
          
                <tr>
            
                <td align="right">2.10 &euro;</td><td>25+</td>
              
                </tr>
            
            </table>
            </center>
                
          </li> 
            </ul>
       </div>
      </div></div></div>   
    </div>
    
    <div class="mainContent">
    
      <a href="/highres_photos.php">[High Resolution Photos]</a>
      <div class="contentTitle">
        61-pos FPC cable 0.3 mm pitch      </div><!-- close contentTitle -->      
          
      <div class="field field-name-body field-type-text-with-summary field-label-hidden"><div class="field-items"><div class="field-item even"><p>61-pos, 0.3 mm pitch, 0.2 mm thich, 40 mm long FPC cable for use with <a href="/products/boards/lpc4088_qsb.php">LPC4088 QuickStart Board</a>.</p>
</div></div></div>      
    </div>
    
      
            <div id="productSection">  <div id="productSectionTitle"><h1>Documentation and Resources</h1></div>  <div id="productSectionContent"><p><strong>Datasheets</strong></p>
<ul><li>
		<a href="/sites/default/files/support/datasheet/e58302093.pdf" target="_blank">FPC connector</a> used on LPC4088 QuickStart Board, Hirose: FH26-61S-0.3SHW(05).<br />
		The datasheet contains information about FPC cable dimensions.</li>
</ul></div></div>            <div id="productSection">  <div id="productSectionTitle"><h1>Related Products</h1></div>  <div id="productSectionContent"><div id="productList"><ul><li>  <div class="leftSection"><a href="/products/boards/lpc4088_qsb.php"><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_product_list/public/image/product/mbed_lpc4088_0.png?itok=kthQPtk6" alt="LPC4088 QuickStart Board" title="LPC4088 QuickStart Board" /></a>  </div>  <div class="midSection">    <div class="title"><a href="/products/boards/lpc4088_qsb.php">LPC4088 QuickStart Board</a></div>    <div class="orderNumber">Order number: EA-QSB-016</div>  </div>  <div class="rightSection">  <span class="price">59&euro;  </span><span><a href="/cart/add/EA-QSB-016/1"><img src="http://www.embeddedartists.com/sites/all/themes/ea1/images/buy3.png" alt="Buy Now" /></a></span>  </div></li></ul></div></div></div>    
      <div id="productSection">  <div id="productSectionTitle"><h1>FAQ</h1></div>  <div id="productSectionContent"><div id="faqList"><ul class="links"><li class="0 first"><a href="/support/faq.php?id=7">Are your boards RoHS 2 compatible?</a></li>
<li class="1"><a href="/support/faq.php?id=21">What is the warranty for your boards?</a></li>
<li class="2"><a href="/support/faq.php?id=39">Do you have high resolution photos of your products?</a></li>
<li class="3"><a href="/support/faq.php?id=45">Do you have a long-term commitment to production and availability of your boards?</a></li>
<li class="4 last"><a href="/support/faq.php?id=51">I cannot download the manuals or files in general. What to do?
</a></li>
</ul></div></div></div>    
    
  </div>



</div>
  </div>
</div>
  </div>
          
    
		</div><!-- close content -->
    
  </div> <!-- /#workArea -->
  
  <div id="footer-wrapper">
    <div id="footer-content">

          <div id="footer-firstcolumn" class="clearfix">
          <div class="region region-footer-firstcolumn">
    <div id="block-block-1" class="block block-block">

    <h2>Useful Information</h2>
  
  <div class="content">
    <ul><li>We are located in Malmö, Sweden.</li>
<li>Embedded Artists AB</li>
<li>Davidshallsgatan 16</li>
<li>211 45 Malmö</li>
</ul><ul><li>Get in touch</li>
<li>Tel +46 (0)40-6110093</li>
<li>Fax +46 (0)40-6110093</li>
<li>Email <a href="/contact">Contact Form</a></li>
</ul><ul><li>Useful Links</li>
<li><a href="/contact">Contact Us</a><a href="contact"> </a></li>
<li><a href="/legal.php">Terms &amp; Conditions</a></li>
<li><a href="/privacy.php">Privacy Policy</a></li>
</ul><ul><li> </li>
<li><a class="feed-icon" href="/rss.xml" target="_blank" title="Subscribe to Embedded Artists RSS Feed"><img alt="Subscribe to Embedded Artists RSS Feed" src="/sites/default/files/image/icons/rss.png" /></a></li>
<li><a href="/newsletter" title="Subscribe to Embedded Artists Newsletter"><img alt="Subscribe to Embedded Artists Newsletter" src="/sites/default/files/image/icons/envelope.png" /></a></li>
<li><a href="https://twitter.com/EmbeddedArtists" title="Follow us on Twitter"><img alt="Follow us on Twitter" src="/sites/default/files/image/icons/twitter.png" /></a></li>
</ul><ul><li> </li>
<li><a href="http://www.youtube.com/user/eavid10?feature=results_main" target="_blank" title="Follow us on YouTube"><img alt="Follow us on YouTube" src="/sites/default/files/image/icons/youtube.png" /></a></li>
<li><a href="http://www.linkedin.com/company/embedded-artists-ab" target="_blank" title="LinkedIn"><img alt="LinkedIn" src="/sites/default/files/image/icons/linkedin.png" /></a></li>
</ul>  </div>
</div>
  </div>
      </div> <!-- /#footer_firstcolumn -->
    
          <div id="footer-secondcolumn" class="clearfix">
          <div class="region region-footer-secondcolumn">
    <div id="block-eashop-ea-partner-view" class="block block-eashop">

    <h2>Partners</h2>
  
  <div class="content">
    <div><a href="/corporate/partners"><ul id="partners"><li><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_partner_view/public/image/partner/nxp_0.png?itok=k8weHDV6" alt="NXP Semiconductors" title="NXP Semiconductors" /></li><li><img src="http://www.embeddedartists.com/sites/default/files/styles/ea_partner_view/public/image/partner/iar.png?itok=bOS-vDRt" alt="IAR" title="IAR" /></li></ul></a></div><div><a href="/corporate/partners"><nobr>&raquo;&nbsp;More</nobr></a></div>  </div>
</div>
  </div>
      </div> <!-- /#footer_secondcolumn -->
        


    
    </div>  <!-- /#footer-content --> 
  </div)> <!-- /#footer-wrapper -->
    <br><center>
      <a href="/product_compliance#iso9001">
        <img src="/sites/default/files/image/misc/iso9001_100.jpg" alt="ISO9001" title="ISO9001" style="width: 70px; height: 70px; margin-right: 10px;">
      </a>

      <a href="/product_compliance#iso14001">
        <img src="/sites/default/files/image/misc/iso14001_100.jpg" alt="ISO14001" title="ISO14001" style="width: 70px; height: 70px; margin-right: 10px;">
      </a>      

      <a href="/sustainability">
        <img alt="" src="/sites/default/files/image/EASB_logo_100.png" style="width: 70px; height: 70px; margin-right: 0px;">
      </a>        
<a href="http://www.soliditet.se/lang/en_GB/RatingGuideline" target="_blank" style="text-decoration: none;"><img style="border:0px;" oncontextmenu="return false" title="Our company is credit worthy according to Bisnode's credit assessment system that is based on a number of decision rules. This credit rating is updated on a daily basis&#44; and always shows the current rating and date." alt="Our company is credit worthy according to Bisnode's credit assessment system that is based on a number of decision rules. This credit rating is updated on a daily basis&#44; and always shows the current rating and date." id="img_273_73_px_tr1" src="https://merit.soliditet.se/merit/imageGenerator/display?lang=EN&country=SE&cId=%2BKrj4TgSYbsfq6wXoGmJ2w%3D%3D&cUid=eCpQb6dCrOQ%3D&imgType=img_273_73_px_tr1" /></a>
    </center>  
  
	<br>
  


  

  <!-- <div class="section"> -->
  


  <!--</div>-->
  
</div></div> <!-- /#page, /#page-wrapper -->



  </body>
</html>
