<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:cc="http://creativecommons.org/ns#" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dct="http://purl.org/dc/terms/" xmlns:frbr="http://purl.org/vocab/frbr/core#" xml:lang="pl">
<head about="http://creativecommons.org/licenses/by-sa/3.0/">
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8"/>
<title>Creative Commons &mdash; Uznanie autorstwa-Na tych samych warunkach 3.0 Unported
&mdash; CC BY-SA 3.0 </title>
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<link rel="stylesheet" type="text/css" href="/includes/yahooapis/2.6.0/container.css"/>
<link rel="stylesheet" type="text/css" href="/includes/deed3.css" media="screen"/>
<link rel="stylesheet" type="text/css" media="print" href="/includes/deed3-print.css"/>
<link rel="stylesheet" type="text/css" href="/includes/jurisdictions.css" media="screen"/>
<!--[if lt IE 7]>
      <link rel="stylesheet" type="text/css"
            href="/includes/deed3-ie.css"
            media="screen" />
    <![endif]-->
<link rel="alternate" type="application/rdf+xml" href="rdf"/>
<script type="text/javascript">
function setCookie(name, value, expires, path, domain, secure) {
    document.cookie= name + "=" + escape(value) +
        ((expires) ? "; expires=" + expires.toGMTString() : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
}
var expiry = new Date();
expiry.setTime(expiry.getTime()+(5*365*24*60*60*1000));
setCookie('lang','%s', expiry, '/');
</script>
<script type="text/javascript" src="/includes/yahooapis/2.6.0/yahoo-dom-event.js"></script>
<script type="text/javascript" src="/includes/yahooapis/2.6.0/connection-min.js"></script>
<script type="text/javascript" src="/includes/yahooapis/2.6.0/json-min.js"></script>
<script type="text/javascript" src="/includes/yahooapis/2.6.0/container-min.js"></script>
<script type="text/javascript" src="//scraper.creativecommons.org/js/deed.js"></script>
<script type="text/javascript" src="/includes/help.js">
    </script>
</head>
<body typeof="cc:License" about="http://creativecommons.org/licenses/by-sa/3.0/" class="yui-skin-sam">
 
 
<div id="deed" class="green" dir="ltr" style="text-align: left">
<div id="deed-head">
<div id="cc-logo">
<img src="/images/deed/cc-logo.jpg" alt="cc logo"/>
</div>
<div id="cc-link">
<a rel="dc:creator dct:creator" href="http://creativecommons.org/">
<span property="dc:title dct:title">Creative Commons</span>
</a>
</div>
<h1><span>Creative Commons License Deed</span></h1>
<div id="deed-license">
<h2>
<span property="dc:title dct:title" style="display: inline;">Uznanie autorstwa-Na tych samych warunkach 3.0 Unported</span>
<span style="display: inline-block; font-size: 14px; padding-left: 2px;">
(<span property="dc:identifier dct:identifier" style="display: inline; font-size: 12px;">CC BY-SA 3.0</span>)
</span>
</h2>
</div>
</div>
<div id="deed-main" dir="ltr" style="text-align: left">
<div id="legalcode-block">
 
<div id="help_disclaimer_popup" class="help_panel">
<div class="hd">Klauzula ograniczenia odpowiedzialności</div>
<div class="bd">
<p>This deed highlights only some of the key features and terms of the actual license. It is not a license and has no legal value. You should carefully review all of the terms and conditions of the actual license before using the licensed material.</p>
<p>Creative Commons is not a law firm and does not provide legal services. Distributing, displaying, or linking to this deed or the license that it summarizes does not create a lawyer-client or any other relationship.</p>
</div>
</div>
<div id="deed-disclaimer">
<div class="summary">
This is a human-readable summary of (and not a substitute for) the <a href="legalcode" class="fulltext">license</a>.
</div>
<div class="disclaimer">
<a href="#" id="disclaimer_popup" class="helpLink">
Klauzula ograniczenia odpowiedzialności
</a>
</div>
</div>
</div>
<div id="deed-main-content" class="">
<div id="libre">
<a href="http://freedomdefined.org/">
<img src="/images/deed/seal.png" style="border: 0" alt="Licencję można stosować do Wolnych Dóbr Kultury."/>
</a>
</div>
<div id="deed-rights" dir="ltr" style="text-align: left">
<h3 resource="http://creativecommons.org/ns#Reproduction" rel="cc:permits">Wolno:</h3>
<ul class="license-properties">
<li class="license share" rel="cc:permits" resource="http://creativecommons.org/ns#Distribution">
<strong>Dzielenie się</strong> &mdash; kopiuj i rozpowszechniaj utwór w dowolnym medium i formacie
</li>
<li class="license remix" rel="cc:permits" resource="http://creativecommons.org/ns#DerivativeWorks">
<strong>Adaptacje</strong> &mdash; remiksuj, zmieniaj i twórz na bazie utworu
</li>
<li class="license commercial">
dla dowolnego celu, także komercyjnego.
</li>
<li id="more-container" class="license-hidden">
<span id="devnations-container"/>
</li>
</ul>
<ul id="license-freedoms-no-icons">
<li class="license">Licencjodawca nie może odwołać udzielonych praw, o ile są przestrzegane warunki licencji.</li>
</ul>
</div>
<div id="deed-conditions">
<h3>Na następujących warunkach:</h3>
<ul dir="ltr" style="text-align: left" class="license-properties">
<li class="license by">
<p>
<strong>Uznanie autorstwa</strong> &mdash; <span rel="cc:requires" resource="http://creativecommons.org/ns#Attribution">Utwór należy <a href="#" id="appropriate_credit_popup" class="helpLink">odpowiednio oznaczyć</a></span>, podać link do licencji i <span rel="cc:requires" resource="http://creativecommons.org/ns#Notice"><a href="#" id="indicate_changes_popup" class="helpLink">wskazać jeśli zostały dokonane w nim zmiany </a></span>. Możesz to zrobić w dowolny, rozsądny sposób, o ile nie sugeruje to udzielania prze licencjodawcę poparcia dla Ciebie lub sposobu, w jaki wykorzystujesz ten utwór.
<span id="by-more-container"></span>
</p>
<p id="work-attribution-container" style="display:none;">
<strong>
Uznaj autorstwo utworu:
</strong>
<br/>
<input id="work-attribution" value="" type="text" readonly="readonly" onclick="this.select()" onfocus="document.getElementById('work-attribution').select();"/>
<input id="license-code" type="hidden" value="CC BY-SA 3.0"/>
<input id="license-url" type="hidden" value="http://creativecommons.org/licenses/by-sa/3.0/"/>
<a href="" id="attribution_help" class="helpLink">
<img src="/images/information.png" alt="Informacje"/>
</a>
</p>
<div id="help_attribution_help" class="help_panel">
<div class="hd">
Co oznacza wymóg "uznania autorstwa utworu"?
</div>
<div class="bd">
Poprzednia strona zawierała zagnieżdżone metadane na temat warunków licencyjnych, łącznie z informacjami dotyczącymi określonych przez twórcę utworu sposobów uznania autorstwa. Powyższy kod HTML służy cytowaniu utworu. Zawarte w kodzie metadane pozwolą innym użytkownikom dotrzeć do oryginalnego utworu.
</div>
</div>
</li>
<li class="license sa" rel="cc:requires" resource="http://creativecommons.org/ns#ShareAlike">
<p>
<strong>Na tych samych warunkach</strong> &mdash; Remiksując utwór, przetwarzając go lub tworząc na jego podstawie, należy swoje dzieło rozpowszechniać na <a href="#" id="same_license_popup" class="helpLink">tej samej licencji</a>, co oryginał.
<span id="sa-more-container"></span>
</p>
</li>
</ul>
</div>
<ul id="deed-conditions-no-icons">
<li class="license">
<strong>Brak dodatkowych ograniczeń</strong> &mdash; Nie możesz korzystać ze środków prawnych <a href="#" id="technological_measures_popup" class="helpLink">lub technologicznych</a>, które ograniczają innych w korzystaniu z utworu na warunkach określonych w licencji.
</li>
</ul>
<div id="deed-understanding">
<h3>
Uwagi:
</h3>
<ul class="understanding license-properties">
<li class="license">
Warunki licencyjne nie muszą być przestrzegane w odniesieniu do tych fragmentów licencjonowanych treści, które znajdują się w domenie publicznej, lub w przypadku sposobów korzystania dozwolonych przez odpowiednie <a href="#" id="exception_or_limitation_popup" class="helpLink">wyjątki lub ograniczenia prawa autorskiego</a>.
</li>
<li class="license">
Licencjodawca nie daje żadnych gwarancji. Licencja może nie zapewniać wszystkich niezbędnych zgód dla niektórych użyć utworu. Dotyczy to w szczególności innych praw, takich jak <a href="#" id="publicity_privacy_or_moral_rights_popup" class="helpLink">ochrona wizerunku, prywatności czy autorskie prawa osobiste</a>. Mogą one ograniczać możliwości wykorzystania utworu.
</li>
</ul>
<div id="help_mediation_and_arbitration_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Odpowiednie zasady mediacji zostaną wskazane w nocie prawnej opublikowanej z utworem, lub w przypadku ich braku we wniosku o mediację. Jeśli nie zaznaczono inaczej w nocie prawnej dołączonej do utworu, zastosowanie mają Reguły Arbitrażowe Komisji Narodów Zjednoczonych do spraw międzynarodowego prawa handlowego (UNCITRAL). </p>
<p><a href="http://wiki.creativecommons.org/Intergovernmental_Organizations#What_should_I_know_before_I_use_a_work_licensed_under_the_IGO_3.0_ported_licenses.3F">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_appropriate_credit_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Należy podać imię i nazwisko twórcy utworu lub innych podmiotów, których autorstwo należy uznać - o ile zostały podane, a także informację prawnoautorską, informację licencyjną, notę o wyłączeniu odpowiedzialności oraz odnośnik do utworu. Licencje CC wcześniejsze niż wersja 4.0 posiadają wymóg podania tytułu utworu - o ile został on podany, oraz mogą mieć inne niewielkie różnice. </p>
<p><a href="http://wiki.creativecommons.org/License_Versions#Detailed_attribution_comparison_chart">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_indicate_changes_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>W wersji 4.0 licencji należy wskazać, czy materiał został zmodyfikowany oraz zachować opisy wcześniejszych modyfikacji (jeśli miały miejsce). W wersji 3.0 oraz wcześniejszych, zaznaczenie zmian było wymagane tylko jeśli powstał utwór zależny.</p>
<p><a href="http://wiki.creativecommons.org/Best_practices_for_attribution#This_is_a_good_attribution_for_material_you_modified_slightly">Wskazówki jak oznaczać</a>.</p>
<p><a href="http://wiki.creativecommons.org/License_Versions#Modifications_and_adaptations_must_be_marked_as_such ">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_same_license_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Można również wykorzystać kompatybilną licencję opisaną na stronie <a href="https://creativecommons.org/compatiblelicenses">https://creativecommons.org/compatiblelicenses</a></p>
<p><a href="http://wiki.creativecommons.org/FAQ#If_I_derive_or_adapt_material_offered_under_a_Creative_Commons_license.2C_which_CC_license.28s.29_can_I_use.3F">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_commercial_purposes_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Przez użycie komercyjne rozumiemy takie, które służy przede wszystkim uzyskaniu korzyści majątkowej lub pieniężnego wynagrodzenia.</p>
<p><a href="http://wiki.creativecommons.org/Frequently_Asked_Questions#Does_my_use_violate_the_NonCommercial_clause_of_the_licenses.3F">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_some_kinds_of_mods_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Sama zmiana formatu nigdy nie powoduje powstania utworu zależnego</p>
<p><a href="http://wiki.creativecommons.org/Frequently_Asked_Questions#When_is_my_use_considered_an_adaptation.3F">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_technological_measures_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Licencja zakazuje wykorzystania skutecznych zabezpieczeń technicznych, zdefiniowanych w odniesieniu do Artykułu 11 traktatu WIPO o prawie autorskim.</p>
<p><a href="http://wiki.creativecommons.org/License_Versions#Application_of_effective_technological_measures_by_users_of_CC-licensed_works_prohibited">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_exception_or_limitation_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Licencje CC nie wpływają na prawa użytkowników wynikające z ograniczeń i wyjątków od prawa autorskiego, takich jak przepisy dozwolonego użytku, fair use czy fair dealing.</p>
<p><a href="http://wiki.creativecommons.org/Frequently_Asked_Questions#Do_Creative_Commons_licenses_affect_exceptions_and_limitations_to_copyright.2C_such_as_fair_dealing_and_fair_use.3F">Więcej informacji</a>.</p>
</div>
</div>
<div id="help_publicity_privacy_or_moral_rights_popup" class="help_panel">
<div class="hd">&nbsp;</div>
<div class="bd">
<p>Dodatkowe zezwolenia mogą być niezbędne aby móc korzystać z utworu w zamierzony sposób.</p>
<p><a href="http://wiki.creativecommons.org/Considerations_for_licensors_and_licensees">Więcej informacji</a>.</p>
</div>
</div>
</div>
<span id="referrer-metadata-container"/>
</div>
</div>
</div>
<div id="footer">
<p>
<a href="http://wiki.creativecommons.org/FAQ">Learn more</a> about CC licensing, or <a id="get_this" href="/choose/results-one?license_code=by-sa&amp;amp;jurisdiction=&amp;amp;version=3.0&amp;amp;lang=pl">use the license</a> for your own material.
</p>
<noscript>
<div id="deed-donate-footer">
<div class="footer-trigger">
<img src="/images/deed/logo-cc-heart-green.png" class="footer-logo" alt="" width="100" height="88"/>
<div class="footer-trigger-content">
<p>This content is freely available under simple legal terms because of Creative Commons, a non-profit that survives on donations. If you love this content, and love that it's free for everyone, please consider a donation to support our work.</p>
<a href="https://donate.creativecommons.org/?utm_campaign=2015fund&utm_source=license_footer2015"><button>Make a Donation</button></a>
</div>
</div>
</div>
</noscript>
<div id="languages">
<span dir="ltr" style="text-align: left">
Strona jest dostępna w następujących językach:
</span>
<br/>
<a title="Castellano" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.es" hreflang="es" xml:lang="es">Castellano</a>
<a title="Castellano (España)" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.es_ES" hreflang="es_ES" xml:lang="es_ES">Castellano (España)</a>
<a title="Català" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.ca" hreflang="ca" xml:lang="ca">Català</a>
<a title="Dansk" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.da" hreflang="da" xml:lang="da">Dansk</a>
<a title="Deutsch" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.de" hreflang="de" xml:lang="de">Deutsch</a>
<a title="English" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.en" hreflang="en" xml:lang="en">English</a>
<a title="Esperanto" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.eo" hreflang="eo" xml:lang="eo">Esperanto</a>
<a title="français" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.fr" hreflang="fr" xml:lang="fr">français</a>
<a title="Galego" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.gl" hreflang="gl" xml:lang="gl">Galego</a>
<a title="hrvatski" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.hr" hreflang="hr" xml:lang="hr">hrvatski</a>
<a title="Indonesia" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.id" hreflang="id" xml:lang="id">Indonesia</a>
<a title="Italiano" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.it" hreflang="it" xml:lang="it">Italiano</a>
<a title="Latviski" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.lv" hreflang="lv" xml:lang="lv">Latviski</a>
<a title="Lietuvių" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.lt" hreflang="lt" xml:lang="lt">Lietuvių</a>
<a title="Magyar" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.hu" hreflang="hu" xml:lang="hu">Magyar</a>
<a title="Melayu" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.ms" hreflang="ms" xml:lang="ms">Melayu</a>
<a title="Nederlands" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.nl" hreflang="nl" xml:lang="nl">Nederlands</a>
<a title="Norsk" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.no" hreflang="no" xml:lang="no">Norsk</a>
<a title="polski" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.pl" hreflang="pl" xml:lang="pl">polski</a>
<a title="Português" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.pt" hreflang="pt" xml:lang="pt">Português</a>
<a title="Português (BR)" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.pt_BR" hreflang="pt_BR" xml:lang="pt_BR">Português (BR)</a>
<a title="Português (Portugal)" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.pt_PT" hreflang="pt_PT" xml:lang="pt_PT">Português (Portugal)</a>
<a title="română" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.ro" hreflang="ro" xml:lang="ro">română</a>
<a title="Suomeksi" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.fi" hreflang="fi" xml:lang="fi">Suomeksi</a>
<a title="svenska" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.sv" hreflang="sv" xml:lang="sv">svenska</a>
<a title="Türkçe" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.tr" hreflang="tr" xml:lang="tr">Türkçe</a>
<a title="íslenska" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.is" hreflang="is" xml:lang="is">íslenska</a>
<a title="česky" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.cs" hreflang="cs" xml:lang="cs">česky</a>
<a title="Ελληνικά" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.el" hreflang="el" xml:lang="el">Ελληνικά</a>
<a title="Беларуская" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.be" hreflang="be" xml:lang="be">Беларуская</a>
<a title="русский" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.ru" hreflang="ru" xml:lang="ru">русский</a>
<a title="українська" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.uk" hreflang="uk" xml:lang="uk">українська</a>
<a title="العربية" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.ar" hreflang="ar" xml:lang="ar">العربية</a>
<a title="پارسی" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.fa" hreflang="fa" xml:lang="fa">پارسی</a>
<a title="中文" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.zh" hreflang="zh" xml:lang="zh">中文</a>
<a title="日本語" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.ja" hreflang="ja" xml:lang="ja">日本語</a>
<a title="華語 (台灣)" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.zh_TW" hreflang="zh_TW" xml:lang="zh_TW">華語 (台灣)</a>
<a title="한국어" rel="alternate nofollow frbr:translation" rev="frbr:translationOf" href="./deed.ko" hreflang="ko" xml:lang="ko">한국어</a>
</div>
</div>
<div id="deed-donate-slide" style="display: none;">
<div class="slide-close"></div>
<div class="slide-trigger">
<img src="/images/deed/logo-cc-heart-white.png" class="slide-logo" alt="" width="100" height="88"/>
<p>This content is freely available under simple legal terms because of Creative Commons, a non-profit that survives on donations. If you love this content, and love that it's free for everyone, please consider a donation to support our work.</p>
<button>Donate Now</button>
</div>
</div>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $('#deed-donate-slide').addClass('slider');
            $('#deed-donate-slide').show();
            // Set banner to reveal after X seconds
            setTimeout(function(){
                $('#deed-donate-slide').addClass('reveal');
            }, 5000);
            $(window).scroll(function() {
                if ($(window).scrollTop() <= 160) {
                    $('#deed-donate-slide').finish();
                    //$('#deed-donate-slide').removeClass('reveal');
                } else {
                    $('#deed-donate-slide').addClass('reveal');
                }
            });

            $('.slide-close').click(function(event) {
                $('#deed-donate-slide').remove();
            });

            /* Close slider on pressing ESC */
            $(document).keyup(function(e) {
                if (e.keyCode === 27) {
                    $('#deed-donate-slide').remove();
                }
            });

            $(".slide-trigger p, .slide-trigger button").click(function(){
                window.location.href = "https://donate.creativecommons.org/?utm_campaign=2015fund&utm_source=license_slide2015";
  
            });
        });
    </script>
<script type="text/javascript">
//<![CDATA[
      var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-2010376-1']);
      _gaq.push(['_trackPageview']);
    
      (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
//]]>
    </script>
<script type="text/javascript">
//<![CDATA[
      document.write("<" + "script type='text/javascript' src='//scraper.creativecommons.org/apps/deed?url=" + encodeURIComponent(document.referrer) + "&amp;license_uri=" + encodeURIComponent(document.URL) + "&amp;callback=YAHOO.cc.success'" + "><" + "/script>");
//]]>
    </script>
 
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//stats.creativecommons.org/piwik/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', 2]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//stats.creativecommons.org/piwik/piwik.php?idsite=2" style="border:0;" alt=""/></p></noscript>
 
</body>
</html>