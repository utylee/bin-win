<!DOCTYPE html>
<html><head><meta charset="utf-8"/><title>How FMF's Models are Copyrighted</title>
<style type="text/css">
	@import "index.css";  
</style>
</head><body>
<div id="banner">
	<a href="http://www.FreeModelFoundry.com">
		<img class="floatleft" src="images/fmf.gif" alt="Free Model Foundry" style="width:317px;height:100px;border:0"/>
	</a>
</div>

<div id="leftcontent">
    <div id="modellibrary"><strong>The Model Library</strong></div>
    <div id="leftnav">
        <ul>
            <li><a href="registration.php">Become a Registered Member</a></li>
            <li><a href="why_register.php">Why Register?</a></li>
            <li><a href="whatsnew.php">What's New</a></li>
            <li>VHDL Models
                <ul>
                    <li><a href="fmf_VHDL_models.php">FMF Models, Packages and Tools</a></li>
                    <li><a href="VHDL_hotlist.php">Other VHDL model sites</a></li>
                </ul>
            </li>
            <li>Verilog Models
                <ul>
                    <li><a href="fmf_vlog_models.php">FMF Models</a></li>
                    <li><a href="vlog_hotlist.php">Other Verilog model sites</a></li>
                </ul>
            </li>
            <li>Cores
                <ul>
                    <li><a href="bip.php">Behavioral IP Models</a></li>
                </ul>
            </li>
            <li><a href="ext_models.php">3rd Party Models</a></li>
            <li><a href="papers.php">White Papers</a></li>
<!--            <li><a href="model_request.html">Request a Model</a></li> -->
            <li><a href="FAQ.php">Frequently Asked Questions</a></li>
            <li><a href="development.php">Model Development</a></li>
        </ul>
    </div>

    <p style="text-align: center;">
        <a href="http://www.FreeModelFoundry.com">
            <img src="images/badge.gif" alt="Free Model Foundry" style="width:125px;height:66px;border:0"/>
        </a>
    </p>
</div>

<div id="centercontent">
	
    <div class="navcontainer">
        <ul>
            <li><a href="index.php" title="Home">Home</a></li>
            <li><a href="about.php" title="About">About</a></li>
            <li><a href="customers.php" title="Customers">Customers</a></li>
            <li><a href="partners.php" title="Partners">Partners</a></li>
            <li><a href="news.php" title="News">News</a></li>
            <li><a href="http://blog.freemodelfoundry.com" title="Blog">Blog</a></li>
            <li><a href="contact.php" title="Contact">Contact</a></li>
        </ul>
    </div>



	<div id="search">
		<form method="POST" action="http://www.freemodelfoundry.com/mod_perl/FMF_search.pl">
			<input type="text"   name="SRCH" size="31" maxlength="60" value="" />
			<input type="submit" value="Search" />
			<INPUT TYPE="hidden" NAME="sp" VALUE="sp">
		</form>
	</div>

<div id="mbox">

<h1>How FMF's Models are Copyrighted</h1>
<p>All models distributed by the Free Model Foundry are considered
to be software and are  protected by the GNU General Public License,
Version 2. As such, you are permitted to  download and use them, without
charge, in any manner you wish. However, redistribution  is subject to
the terms and conditions of the license.</P>
<P>Please download and read the <A HREF="copyleft.txt">license.</A></P>

	
<p>FMF can be Contacted through Richard Munden: <a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#109;&#117;&#110;&#100;&#101;&#110;&#64;&#102;&#114;&#101;&#101;&#109;&#111;&#100;&#101;&#108;&#102;&#111;&#117;&#110;&#100;&#114;&#121;&#46;&#99;&#111;&#109;">
&#109;&#117;&#110;&#100;&#101;&#110;&#64;&#102;&#114;&#101;&#101;&#109;&#111;&#100;&#101;&#108;&#102;&#111;&#117;&#110;&#100;&#114;&#121;&#46;&#99;&#111;&#109;</a></p>


</div>

    <div class="navcontainer">
        <ul>
            <li><a href="index.php" title="Home">Home</a></li>
            <li><a href="about.php" title="About">About</a></li>
            <li><a href="customers.php" title="Customers">Customers</a></li>
            <li><a href="partners.php" title="Partners">Partners</a></li>
            <li><a href="news.php" title="News">News</a></li>
            <li><a href="http://blog.freemodelfoundry.com" title="Blog">Blog</a></li>
            <li><a href="contact.php" title="Contact">Contact</a></li>
        </ul>
    </div>


	<footer style="text-align:center;font-size:10px">
    Copyright &copy; 2016 Free Model Foundry, 6501 Longridge Way, Sacramento, CA 95831, USA<br />
    Verbatim copying and distribution is permitted in any medium, provided this notice is preserved.
    <br />Updated: 2010 May 04
	</footer>

</div>

<div id="rightcontent">
  <!--Google Ad-->
</div>
	
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-407760-1";
urchinTracker();
</script>


</body></html>
